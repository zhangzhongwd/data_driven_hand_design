import os, inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(os.path.dirname(currentdir))
os.sys.path.insert(0, parentdir)

import pybullet as p
import numpy as np
import copy
import math
import pybullet_data_zhong


class Shadow_hand:

  def __init__(self, urdfRootPath=pybullet_data_zhong.getDataPath(), timeStep=0.01):
    self.urdfRootPath = urdfRootPath
    self.timeStep = timeStep
    self.maxVelocity = .35
    self.maxForce = 200.
    self.useSimulation = 1
    self.useOrientation = 1
    self.fixed_base = 1

    self.reset()

  def reset(self):
    objects=p.loadURDF(os.path.join(self.urdfRootPath, "sr_grasp_description/urdf/shadow_hand_raw_block.urdf"), [-0.05, 0.1, 0.1], [ 0.5, -0.5, 0.5, 0.5 ],
                       useFixedBase=self.fixed_base,flags=p.URDF_USE_SELF_COLLISION)
    self.shadow_hand_Uid = objects
    # p.resetBasePositionAndOrientation(self.shadow_hand_Uid, [0, 0.000000, 0.2],
    #                                   [0.000000, 0.000000, 0.000000, 1.000000])


    self.numJoints = p.getNumJoints(self.shadow_hand_Uid)
    print ('numJoints is %d'%self.numJoints)

    self.jointPositions = [0] * self.numJoints
    # self.jointPositions[23]=1.571
    # self.jointPositions[24]=1.571

    for jointIndex in range(self.numJoints):
      p.resetJointState(self.shadow_hand_Uid, jointIndex, self.jointPositions[jointIndex])
      p.setJointMotorControl2(self.shadow_hand_Uid,
                              jointIndex,
                              p.POSITION_CONTROL,
                              targetPosition=self.jointPositions[jointIndex],
                              force=self.maxForce)

    self.motorNames = []
    self.motorIndices = []

    for i in range(self.numJoints):
      # print ('i is %d'%i)
      jointInfo = p.getJointInfo(self.shadow_hand_Uid, i)
      # print (jointInfo)
      qIndex = jointInfo[3]
      # print (qIndex)
      if qIndex > -1:
        self.motorNames.append(str(jointInfo[1]))
        self.motorIndices.append(i)
    # print (self.motorNames)
    # print (len(self.motorIndices))

  def getActionDimension(self):
    return 22
    # if (self.useInverseKinematics):
    #   return len(self.motorIndices)
    # return 6  #position x,y,z and roll/pitch/yaw euler angles of end effector

  # def getObservationDimension(self):
  #   return len(self.getObservation())
  #
  # def getObservation(self):
  #   observation = []
  #   state = p.getLinkState(self.kukaUid, self.kukaGripperIndex)
  #   pos = state[0]
  #   orn = state[1]
  #   euler = p.getEulerFromQuaternion(orn)
  #
  #   observation.extend(list(pos))
  #   observation.extend(list(euler))
  #   # print ('observation is')
  #   # print (observation)
  #   return observation
  #

  # def applyAction(self, motorCommands):
  #   for action in range(len(motorCommands)):
  #     motor = self.motorIndices[action]
  #     p.setJointMotorControl2(self.shadow_hand_Uid,
  #                             motor,
  #                             p.POSITION_CONTROL,
  #                             targetPosition=motorCommands[action],
  #                             force=self.maxForce)

  def applyAction(self, motorCommands):
    # for jointIndex in range(self.numJoints):
    #   p.resetJointState(self.shadow_hand_Uid, jointIndex, self.jointPositions[jointIndex])
    # todo: motorCommands is current joint states - last time joint states
    current_states_all=p.getJointStates(self.shadow_hand_Uid, self.motorIndices)
    current_states=[current_states_all[i][0] for i in range(len(motorCommands))]
    # print (current_states)
    for action in range(len(motorCommands)):
      motor = self.motorIndices[action]
      p.setJointMotorControl2(self.shadow_hand_Uid,
                              motor,
                              p.POSITION_CONTROL,
                              targetPosition=current_states_all[action][0]+motorCommands[action],
                              # targetPosition=0 + motorCommands[action],
                              force=self.maxForce)


# if __name__ == '__main__':
#     p.connect(p.GUI)
#     h=Shadow_hand()
#     while 1:
#         continue
