import os, inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(os.path.dirname(currentdir))
os.sys.path.insert(0, parentdir)

import pybullet as p
import pybullet_data_zhong

from urdf_constructed_function import create_hand


class Self_reconstructed_hand:

    def __init__(self, urdfRootPath=pybullet_data_zhong.getDataPath(), timeStep=1.0/240.0, hand_position=[0.5,0,0.5], hand_oritation=[0,0,0,1]):
        self.urdfRootPath = urdfRootPath
        self._timeStep = timeStep
        self.maxVelocity = .35
        self.maxForce = 20.
        self.useSimulation = 1
        self.useOrientation = 1
        self.fixed_base = 1
        self.fingertip_index=[]
        self.link_sum=0
        self.hand_position=hand_position
        self.hand_oritation=hand_oritation
        self.finger_number=10
        self.single_finger_joint_number=6
        self.base_xyz=[0.06,0.016,0.05]
        self.link_length_list=[0.016, 0.021, 0.026, 0.031, 0.036, 0.041, 0.046, 0.051, 0.056, 0.062]
        self.link_width=0.008
        self.object_index=2
        self.reset()


    def reset(self):
        self.hand_state=[[0 for col in range(self.single_finger_joint_number*2)] for row in range(self.finger_number)]
        # self.hand_state[0]=[1,2,10,1,10,1,10,1,0,0,0,0]
        self.hand_state[0] = [4, 2, 7, 1, 2, 1, 10, 1, 0, 0, 0, 0]
        self.hand_state[1] = [10, 2, 1, 1, 1, 1, 10, 1, 0, 0, 0, 0]
        self.hand_state[2] = [1, 2, 1, 1, 10, 1, 1, 1, 0, 0, 0, 0]
        self.hand_state[3] = [5, 2, 10, 1, 10, 1, 1, 1, 0, 0, 0, 0]
        self.hand_state[4] = [1, 2, 10, 1, 10, 1, 10, 1, 0, 0, 0, 0]
        self.hand_state[5] = [3, 2, 3, 1, 3, 1, 9, 1, 0, 0, 0, 0]
        self.hand_state[6] = [7, 2, 10, 1, 1, 1, 10, 1, 0, 0, 0, 0]
        self.hand_state[7] = [1, 2, 5, 1, 5, 1, 5, 1, 0, 0, 0, 0]
        # self.hand_state[4]=[1,2,10,1,10,1,10,1,0,0,0,0]
        # self.hand_state[5]=[1,2,10,1,10,1,10,1,0,0,0,0]
        self.hand_state[8] = [6, 2, 6, 1, 1, 1, 1, 1, 0, 0, 0, 0]
        self.hand_state[9] = [1, 2, 1, 1, 8, 1, 8, 1, 0, 0, 0, 0]


        urdf_file_name,self.finger_abduction_adduction_index,self.finger_abduction_adduction_in_which_side,self.finger_flex_index\
            =create_hand(self.urdfRootPath, self.hand_state, self.base_xyz, self.link_length_list, self.link_width)


        self.self_reconstructed_hand_Uid = p.loadURDF(os.path.join(self.urdfRootPath, urdf_file_name),
                                                      self.hand_position, self.hand_oritation, useFixedBase=1,
                                                      flags=p.URDF_USE_SELF_COLLISION | p.URDF_USE_SELF_COLLISION_EXCLUDE_PARENT)




        self.numJoints = p.getNumJoints(self.self_reconstructed_hand_Uid)
        print ('numJoints is {0}'.format(self.numJoints))
        self.jointPositions = [0]* self.numJoints

        p.setGravity(0, 0, -10)
        p.resetDebugVisualizerCamera(0.5, 180, 0, self.hand_position)



if __name__ == '__main__':
    print ('1')
    p.connect(p.GUI)


    h=Self_reconstructed_hand()
    hand_Uid=h.self_reconstructed_hand_Uid

    numJoints = p.getNumJoints(hand_Uid)
    jointPositions = [0] * numJoints
    print(numJoints)


    motorsIds = []

    dv = 1.57
    for i in range(numJoints):
      a = 'joint_' + str(i + 1)
      motorsIds.append(p.addUserDebugParameter('joint_' + str(i + 1), -dv, dv, 0))


    def applyAction(motorCommands):
      for action in range(len(motorCommands)):
          motor = action
          p.setJointMotorControl2(hand_Uid,
                                  motor,
                                  p.POSITION_CONTROL,
                                  targetPosition=motorCommands[action],
                                  force=200)

    done = False
    while (not done):
      action = []
      for motorId in motorsIds:
          action.append(p.readUserDebugParameter(motorId))
      applyAction(action)
      p.stepSimulation()
