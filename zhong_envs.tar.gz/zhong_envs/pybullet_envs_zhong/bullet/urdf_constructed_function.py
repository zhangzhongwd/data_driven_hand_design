import os, inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(os.path.dirname(currentdir))
os.sys.path.insert(0, parentdir)

import pybullet as p
import numpy as np
import copy
import math
import pybullet_data_zhong
import random




def create_hand(urdfRootPath,hand_state,base_xyz,link_length_list,link_width=0.008):

    '''
    :param urdfRootPath: file storage path
    :param hand_state: It contains hand shape information, its dimension is [finger_number,joint_number*2],
                       every row contains link length and axis. For example:
                       length has 10 types,you can choose length from 1-10, axis has 2 types, can be chosen from 1-2
                       [[10,1,1,1,2,1,0,0,0,0,0,0],
                        [0,0,0,0,0,0,0,0,0,0,0,0],
                        [0,0,0,0,0,0,0,0,0,0,0,0]]
                       This matrix means the palm only has 1 finger, this finger has 3 links and 3 joints.
                       The first link has 10th length and 1st axis
                       The second link has 1st length and 1st axis
                       The third link has 2nd length and 1st axis


    base xxx:                       corresponding hand palm parameters
    link_xx:                        corresponding finger link parameters


    finger_link_name:               corresponding link name, like [link_1,link_2,link3]
    finger_link_xyz:                corresponding link xyz,  like [[0,0,0],[0,1,1],[1,2,3]]
    finger_link_rpy:                corresponding link rpy,  like [[0,0,0],[0,1,1],[1,0,0]]
    finger_link_size:               chosen by link length
    finger_link_size_type_choose:   corresponding link size choose, like [[0,1],[0]]

    joint_name:                     corresponding joint name,like [joint_1,joint_2,joint_3]
    joint_axis:                     corresponding joint axis, like [[0,0,1],[0,1,0],[1,0,0]]
    joint_xyz:                      corresponding joint xyz,  like [[0,0,0],[0,1,1],[1,2,3]]
    joint_rpy:                      corresponding joint rpy,  like [[0,0,0],[0,1,1],[1,0,0]]


    color : define material type

    note:
    initial, link coordinate is equal to link joint coordinate
    joint xyz rpy is child link joint coordinate relative to parent link joint coordinate
    link xyz rpy is link coordinate relative to link joint coordinate
    if initial matrix is [1,0,0,1,0,1], the link coordinate is fixed in the link gravity center

    :return:
    '''


    # print ('we have creat a new robotics hand')

    base_x=base_xyz[0]
    base_y=base_xyz[1]
    base_z=base_xyz[2]
    base_size = [base_x,base_y,base_z]
    # link_length=[0.016,0.020,0.024,0.028,0.032,0.036,0.040,0.044,0.048,0.052]
    link_length = link_length_list
    # link_width=0.008


    finger_link_name = []
    finger_link_xyz = []
    finger_link_rpy = []
    finger_link_size = []

    joint_name = []
    joint_xyz = []
    joint_rpy = []
    joint_axis = []

    # todo:check whether the format of hand_state is legal or not, if illegal, print red warning
    finger_number=int(np.array(hand_state).shape[0])
    link_joint_number=int(np.array(hand_state).shape[1]/2)
    # print ('link number type is {0}'.format(type(link_joint_number)))
    # print ('finger number is {0}, joint number is {1}'.format(finger_number,link_joint_number))
    hand_state_legal_flag=1
    for i in range(finger_number):
        if 0 in hand_state[i]:
            if sum(hand_state[i][hand_state[i].index(0):])!=0:
                hand_state_legal_flag=0
                # print ('\033[1;31;40mWarning: hand_state is illegal\033[0m')
                break

    link_count=0
    finger_start_index=[]
    finger_abduction_adduction_index=[]
    finger_flex_index=[]
    finger_abduction_adduction_in_which_side=[]
    for i in range(finger_number):
        for j in range(link_joint_number):
            # print ('i is {0}, j is {1}'.format(i,j))
            if hand_state[i][j*2]==0:
                break
            else:
                link_count=link_count+1
                finger_link_name.append('link_' + str(link_count))
                joint_name.append('joint_' + str(link_count))
                finger_link_xyz.append([0, 0, link_length[hand_state[i][j*2]-1] / 2.0])
                finger_link_rpy.append([0, 0, 0])
                finger_link_size.append([link_width,link_width, link_length[ hand_state[i][j*2]-1 ] ])
                if i < finger_number/2.0:
                    if j == 0:
                        joint_xyz.append([-(base_x-link_width)/2.0+(base_x-link_width)/4.0*i, 0, base_z / 2.0])
                        joint_rpy.append([0, 0, math.pi])
                        finger_start_index.append(link_count-1)
                    else:
                        joint_xyz.append([0, 0, link_length[hand_state[i][j*2-2]-1]])
                        joint_rpy.append([0, 0, 0])
                    if hand_state[i][j*2+1]==1:
                        joint_axis.append([1,0,0])
                        finger_flex_index.append(link_count-1)
                    elif hand_state[i][j*2+1]==2:
                        joint_axis.append([0,1,0])
                        finger_abduction_adduction_index.append(link_count-1)
                        finger_abduction_adduction_in_which_side.append(1)
                else:
                    if j == 0:
                        joint_xyz.append([-(base_x-link_width)/2.0+(base_x-link_width)/4.0*(i-finger_number/2), 0, - base_z / 2.0])
                        joint_rpy.append([math.pi, 0, 0])
                        finger_start_index.append(link_count - 1)
                    else:
                        joint_xyz.append([0, 0, link_length[hand_state[i][j*2-2]-1]])
                        joint_rpy.append([0, 0, 0])
                    if hand_state[i][j * 2 + 1] == 1:
                        joint_axis.append([1, 0, 0])
                        finger_flex_index.append(link_count - 1)
                    elif hand_state[i][j * 2 + 1] == 2:
                        joint_axis.append([0, 1, 0])
                        finger_abduction_adduction_index.append(link_count - 1)
                        finger_abduction_adduction_in_which_side.append(-1)


    color = ['Red', 'Blue', 'Green', 'Yellow', 'White', 'Black','Orange','Purple']

    # print ('create hand and link number is {0}'.format(link_count))


    urdf_file_name='urdf_constructed_hand_'+str(random.random())+'.urdf'
    with open(urdfRootPath + '/'+urdf_file_name, 'w+') as f:
        start = '<robot name="self_reconstructed_hand">\n' \
                '<material name="Blue">\n' \
                '<color rgba="0.0 0.0 0.8 1.0"/>\n' \
                '</material>\n' \
                '<material name="Green">\n' \
                '<color rgba="0.0 0.8 0.0 1.0"/>\n' \
                '</material>\n' \
                '<material name="Yellow">\n' \
                '<color rgba="1.0 0.84 0.0 1.0"/>\n' \
                '</material>\n' \
                '<material name="Red">\n' \
                '<color rgba="0.8 0.0 0.0 1.0"/>\n' \
                '</material>\n' \
                '<material name="White">\n' \
                '<color rgba="1.0 1.0 1.0 1.0"/>\n' \
                '</material>\n' \
                '<material name="Black">\n' \
                '<color rgba="0.0 0.0 0.0 1.0"/>\n' \
                '</material>\n' \
                '<material name="Orange">\n' \
                '<color rgba="1.0 0.5 0.0 1.0"/>\n' \
                '</material>\n' \
                '<material name="Purple">\n' \
                '<color rgba="0.8 0.0 0.8 1.0"/>\n' \
                '</material>\n' \
                '\n'
        f.write(start)

        s_base_size = str(base_size).replace('[', '"').replace(']', '"').replace(',', ' ')
        base = '<link name="base">\n' \
               '<inertial>\n' \
               '<origin rpy="0 0 0" xyz="0.0 0.0 0.0"/>\n' \
               '<mass value="0.1"/>\n' \
               '<inertia ixx="1" ixy="0" ixz="0" iyy="1" iyz="0" izz="1"/>\n' \
               '</inertial>\n' \
               '<visual>\n' \
               '<origin rpy="0 0 0" xyz="0 0 0.0"/>\n' \
               '<geometry name="base_visual">\n' \
               '<box size=' + s_base_size + '/>\n' \
                                            '</geometry>\n' \
                                            '<material name="Red"/>\n' \
                                            '</visual>\n' \
                                            '<collision>\n' \
                                            '<origin rpy="0 0 0" xyz="0.0 0.0 0.0"/>\n' \
                                            '<geometry name="base_collision">\n' \
                                            '<box size=' + s_base_size + '/>\n' \
                                                                         '</geometry>\n' \
                                                                         '</collision>\n' \
                                                                         '</link>\n' \
                                                                         '\n'
        f.write(base)



        current_index=0
        for i in range(link_count):
            if i in finger_start_index:
                if joint_axis[i]==[0,1,0]:
                    current_color=color[1]
                    current_index = i
                elif joint_axis[i]==[1,0,0]:
                    current_color=color[2]
                    current_index = i-1
            else:
                current_color=color[i-current_index+1]


            current_link = '<link name="' + finger_link_name[i] + '">\n' \
                                                '<inertial>\n' \
                                                '<origin rpy="0 0 0" xyz="0 0 0"/>\n' \
                                                '<mass value="0.01"/>\n' \
                                                '<inertia ixx="1" ixy="0" ixz="0" iyy="1" iyz="0" izz="1"/>\n' \
                                                '</inertial>\n' \
                                                '<visual>\n' \
                                                '<origin rpy=' + str(finger_link_rpy[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + 'xyz=' + str(finger_link_xyz[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                                    '<geometry name="' +finger_link_name[i] + '_visual">\n' \
                                                            '<box size=' + str(finger_link_size[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                                    '</geometry>\n' \
                                                    '<material name="' +current_color + '"/>\n' \
                                                '</visual>\n' \
                                                '<collision>\n' \
                                                    '<origin rpy=' + str(finger_link_rpy[i]).replace('[','"').replace(']', '"').replace(',', ' ') + 'xyz=' + str(finger_link_xyz[i]).replace('[', '"').replace(']','"').replace(',', ' ') + '/>\n' \
                                                    '<geometry name="' + finger_link_name[i] + '_collision">\n' \
                                                        '<box size=' + str(finger_link_size[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                                    '</geometry>\n' \
                                                '</collision>\n' \
                                             '</link>\n' \
                                             '\n'
            f.write(current_link)

            if i in finger_start_index:
                if joint_axis[i]==[1,0,0]:
                    current_joint = '<joint name="' + joint_name[i] + '" type="' + 'revolute' + '">\n' \
                                    '<parent link="base"/>\n' \
                                    '<child link="' + finger_link_name[i] + '"/>\n' \
                                    '<axis xyz=' + str(joint_axis[i]).replace('[','"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                    '<origin rpy=' + str(joint_rpy[i]).replace('[','"').replace(']', '"').replace(',', ' ') + 'xyz=' + str(joint_xyz[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                    '<limit  effort="100" velocity="1.0" lower="0" upper="3.14"/>\n' \
                                    '</joint>\n' \
                                    '\n'
                elif joint_axis[i]==[0,1,0]:
                    current_joint = '<joint name="' + joint_name[i] + '" type="' + 'revolute' + '">\n' \
                                    '<parent link="base"/>\n' \
                                    '<child link="' +finger_link_name[i] + '"/>\n' \
                                    '<axis xyz=' + str(joint_axis[i]).replace('[','"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                    '<origin rpy=' + str(joint_rpy[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + 'xyz=' + str(joint_xyz[i]).replace('[', '"').replace(']','"').replace(',', ' ') + '/>\n' \
                                    '<limit  effort="100" velocity="1.0" lower="-1.57" upper="1.57"/>\n' \
                                    '</joint>\n' \
                                    '\n'
            else:
                if joint_axis[i]==[1,0,0]:
                    current_joint = '<joint name="' + joint_name[i] + '" type="' + 'revolute' + '">\n' \
                                    '<parent link="' + finger_link_name[i-1] + '"/>\n' \
                                    '<child link="' + finger_link_name[i] + '"/>\n' \
                                    '<axis xyz=' + str(joint_axis[i]).replace('[','"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                    '<origin rpy=' + str(joint_rpy[i]).replace('[','"').replace(']', '"').replace(',', ' ') + 'xyz=' + str(joint_xyz[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                    '<limit  effort="100" velocity="1.0" lower="0" upper="3.14"/>\n' \
                                    '</joint>\n' \
                                    '\n'
                elif joint_axis[i]==[0,1,0]:
                    current_joint = '<joint name="' + joint_name[i] + '" type="' + 'revolute' + '">\n' \
                                    '<parent link="' + finger_link_name[i - 1] + '"/>\n' \
                                    '<child link="' + finger_link_name[i] + '"/>\n' \
                                    '<axis xyz=' + str(joint_axis[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                    '<origin rpy=' + str(joint_rpy[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + 'xyz=' + str(joint_xyz[i]).replace('[', '"').replace(']', '"').replace(',', ' ') + '/>\n' \
                                    '<limit  effort="100" velocity="1.0" lower="-1.57" upper="1.57"/>\n' \
                                    '</joint>\n' \
                                     '\n'


            f.write(current_joint)
        f.write('</robot>')

    # print ('urdf is written in {0}'.format(urdfRootPath))
    # return fingertip_index, link_number_sum
    # print ('finger_abduction_adduction_index is {0}'.format(finger_abduction_adduction_index))
    return urdf_file_name,finger_abduction_adduction_index,finger_abduction_adduction_in_which_side,finger_flex_index


# class Self_reconstructed_hand:
#
#   def __init__(self, urdfRootPath=pybullet_data_zhong.getDataPath(), timeStep=0.01, hand_position=[0,0,0], hand_oritation=[0,0,0,1]):
#     self.urdfRootPath = urdfRootPath
#     self.timeStep = timeStep
#     self.maxVelocity = .35
#     self.maxForce = 20.
#     self.useSimulation = 1
#     self.useOrientation = 1
#     self.fixed_base = 1
#     self.fingertip_index=[]
#     self.link_sum=0
#     self.hand_position=hand_position
#     self.hand_oritation=hand_oritation
#     self.finger_number=10
#     self.single_finger_joint_number=6
#     self.reset()
#
#
#   def reset(self):
#     # print ('reset')
#     print (self.urdfRootPath)
#     # hand_state=[[0]*(self.single_finger_joint_number*2)]*self.finger_number
#     hand_state = [[0 for col in range(self.single_finger_joint_number * 2)] for row in range(self.finger_number)]
#     hand_state[0] = [1, 2, 2, 1, 3, 1, 4, 1, 0, 0, 0, 0]
#     hand_state[2] = [1, 2, 10, 1, 10, 1, 10, 1, 10, 1, 0, 0]
#     hand_state[4] = [1, 2, 5, 1, 6, 1, 7, 1, 0, 0, 0, 0]
#     hand_state[5] = [1, 2, 4, 1, 3, 1, 2, 1, 0, 0, 0, 0]
#     hand_state[9] = [1, 2, 10, 1, 10, 1, 10, 1, 0, 0, 0, 0]
#     print ('hand_state is {0}'.format(hand_state))
#     urdf_file_name,_,_,_=create_hand(self.urdfRootPath,hand_state,[0.06,0.016,0.05],
#                                      [0.016, 0.020, 0.024, 0.028, 0.032, 0.036, 0.040, 0.044, 0.048, 0.052],0.008)
#     print ('path is {0}'.format(os.path.join(self.urdfRootPath, urdf_file_name)))
#     self.self_reconstructed_hand_Uid = p.loadURDF(os.path.join(self.urdfRootPath, 'urdf_constructed_hand.urdf'),
#                                                   self.hand_position, self.hand_oritation, useFixedBase=1,
#                                                   flags=p.URDF_USE_SELF_COLLISION | p.URDF_USE_SELF_COLLISION_EXCLUDE_PARENT)
#     p.resetBasePositionAndOrientation(self.self_reconstructed_hand_Uid, [0,0,0], p.getQuaternionFromEuler([math.pi / 2, math.pi/2, 0]))
#
#     # self.self_reconstructed_hand_Uid = p.loadURDF(os.path.join(self.urdfRootPath, "integrated_hand_test.urdf"),
#     #                                               self.hand_position, self.hand_oritation, useFixedBase=1,
#     #                                               flags=p.URDF_USE_SELF_COLLISION | p.URDF_USE_SELF_COLLISION_EXCLUDE_PARENT)
#
#     # p.resetBasePositionAndOrientation(self.self_reconstructed_hand_Uid, [0, 0.1, 0.1]
#     #                                   [0.5, -0.5, 0.5, 0.5])u
#     self.numJoints = p.getNumJoints(self.self_reconstructed_hand_Uid)
#     self.jointPositions = [0]* self.numJoints
#
#     for i in range(self.numJoints):
#         p.changeDynamics(self.self_reconstructed_hand_Uid, i, lateralFriction=0.2, spinningFriction=0.001)
#     p.changeDynamics(self.self_reconstructed_hand_Uid, -1, lateralFriction=0.2, spinningFriction=0.001)
#
#     # self.jointPositions[16]=1.571
#     # print ('numJoints is %d'%self.numJoints)
#     for jointIndex in range(self.numJoints):
#       p.resetJointState(self.self_reconstructed_hand_Uid, jointIndex, self.jointPositions[jointIndex])
#
#
#       p.setJointMotorControl2(self.self_reconstructed_hand_Uid,
#                               jointIndex,
#                               p.POSITION_CONTROL,
#                               targetPosition=self.jointPositions[jointIndex],
#                               force=self.maxForce)
#
#
#     self.motorNames = []
#     self.motorIndices = []
#
#     for i in range(self.numJoints):
#       # print ('i is %d'%i)
#       jointInfo = p.getJointInfo(self.self_reconstructed_hand_Uid, i)
#       # print (jointInfo)
#       qIndex = jointInfo[3]
#       # print ('qIndex is {0}'.format(qIndex))
#       if qIndex > -1:
#         self.motorNames.append(str(jointInfo[1]))
#         self.motorIndices.append(i)
#
#   def getActionDimension(self):
#     return len(self.motorIndices)
#
#
#   def applyAction(self, motorCommands):
#     # for jointIndex in range(self.numJoints):
#     #   p.resetJointState(self.self_reconstructed_hand_Uid, jointIndex, self.jointPositions[jointIndex])
#     # todo: motorCommands is current joint states - last time joint states
#     current_states_all=p.getJointStates(self.self_reconstructed_hand_Uid, self.motorIndices)
#     # current_states=[current_states_all[i][0] for i in range(len(motorCommands))]
#     # print (current_states)
#     for action in range(len(motorCommands)):
#       motor = self.motorIndices[action]
#       p.setJointMotorControl2(self.self_reconstructed_hand_Uid,
#                               motor,
#                               p.POSITION_CONTROL,
#                               targetPosition=current_states_all[action][0]+motorCommands[action],
#                               force=self.maxForce
#                               )
#
#
#
# if __name__ == '__main__':
#     p.connect(p.GUI)
#
#     h=Self_reconstructed_hand()
#     hand_Uid=h.self_reconstructed_hand_Uid
#
#     numJoints = p.getNumJoints(hand_Uid)
#     jointPositions = [0] * numJoints
#     print(numJoints)
#
#
#     p.setGravity(0, 0, -10)
#     p.resetDebugVisualizerCamera(0.5, 150, -30, [0, 0, 0])
#
#     motorsIds = []
#
#     dv = 1.57
#     for i in range(numJoints):
#       a = 'joint_' + str(i + 1)
#       motorsIds.append(p.addUserDebugParameter('joint_' + str(i + 1), -dv, dv, 0))
#
#
#     def applyAction(motorCommands):
#       for action in range(len(motorCommands)):
#           motor = action
#           p.setJointMotorControl2(hand_Uid,
#                                   motor,
#                                   p.POSITION_CONTROL,
#                                   targetPosition=motorCommands[action],
#                                   force=200)
#
#     done = False
#     while (not done):
#       action = []
#       for motorId in motorsIds:
#           action.append(p.readUserDebugParameter(motorId))
#       applyAction(action)
#       for i in [1]:
#         # print ('link {0} position is {1}, orientation is {2}, '
#         #        'local position offset is {3}'.format(i, p.getLinkState(hand_Uid,i)[0],p.getLinkState(hand_Uid,i)[1],p.getLinkState(hand_Uid,i)[2]))
#         # print (p.getJointInfo(hand_Uid,i)[13],p.getJointInfo(hand_Uid,i)[14],p.getJointInfo(hand_Uid,i)[15])
#
#         # print ('link {0} world position is {1}, world orientation is {2}'.format(i,
#         #                                                                          p.getLinkState(hand_Uid, i)[0],
#         #                                                                          p.getLinkState(hand_Uid, i)[1]))
#         # axis_orientation=np.array(p.getMatrixFromQuaternion(p.getLinkState(hand_Uid, i)[1])).reshape(3,3)
#         # axis_towards=np.array(p.getJointInfo(hand_Uid,i)[13]).reshape(-1,1)
#         # print ('axis_orientation is {0}'.format(axis_orientation))
#         # print ('axis_towards is {0}'.format(axis_towards))
#         axis_direction=np.dot(np.array(p.getMatrixFromQuaternion(p.getLinkState(hand_Uid, i)[1])).reshape(3,3),np.array(p.getJointInfo(hand_Uid,i)[13]).reshape(-1,1))
#         print ('axis {0} direction is {1}'.format(i,axis_direction.reshape(1,3)))
#         # print('world link {0} position is {1}, '
#         #       'world orientation is {2}'.format(i, p.getLinkState(hand_Uid, i)[4], p.getLinkState(hand_Uid, i)[5]))
#       p.stepSimulation()
#   # while 1:
#   #     continue




