import os, inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
print("current_dir=" + currentdir)
os.sys.path.insert(0, currentdir)

import gym
from gym import spaces
import numpy as np
import time
import pybullet as p
import Shadow_hand
import pybullet_data_zhong

largeValObservation = 0.5

RENDER_HEIGHT = 720
RENDER_WIDTH = 960


class HandGymEnv(gym.Env):
  metadata = {'render.modes': ['human', 'rgb_array'], 'video.frames_per_second': 50}

  def __init__(self,
               urdfRoot=pybullet_data_zhong.getDataPath(),
               actionRepeat=1,
               isEnableSelfCollision=True,
               renders=True,
               isDiscrete=False,
               maxSteps=100000):
    #print("KukaGymEnv __init__")
    self._isDiscrete = isDiscrete
    self._timeStep = 1. / 240.
    self._urdfRoot = urdfRoot
    self._actionRepeat = actionRepeat
    self._isEnableSelfCollision = isEnableSelfCollision
    self._observation = []
    self._observation_sum=0        #todo:remember set 0 when reset
    self._envStepCounter = 0
    self._renders = renders
    self._maxSteps = maxSteps
    self.terminated = 0
    self._cam_dist = 1.3
    self._cam_yaw = 180
    self._cam_pitch = -40
    self._contactinfo=[]
    self._contactinfo_compute=[]
    self._contactnumber=[]

    self._p = p

    # print (self._urdfRoot)
    if self._renders:
      cid = p.connect(p.SHARED_MEMORY)
      if (cid < 0):
        cid = p.connect(p.GUI)
      p.resetDebugVisualizerCamera(1.3, 180, -41, [0.52, -0.2, -0.33])
    else:
      p.connect(p.DIRECT)
    self.seed()
    self.reset()
    observationDim = len(self.getExtendedObservation())


    observation_high = np.array([largeValObservation] * observationDim)
    if (self._isDiscrete):
      self.action_space = spaces.Discrete(7)
    else:
      action_dim = 22
      self._action_bound = 1.571
      action_high = np.array([self._action_bound] * action_dim)
      self.action_space = spaces.Box(-action_high, action_high)
      print (self.action_space)
    self.observation_space = spaces.Box(-observation_high, observation_high)
    # print (self.observation_space)
    self.viewer = None

  def reset(self):
    print("hand _reset")
    self.terminated = 0
    self._observation_sum = 0
    p.resetSimulation()
    p.setPhysicsEngineParameter(numSolverIterations=150)
    p.setTimeStep(self._timeStep)
    self._plane_Uid=p.loadURDF(os.path.join(self._urdfRoot, "plane.urdf"), [0, 0, 0])

    self._object_Uid=p.loadURDF(os.path.join(self._urdfRoot, "block_0.04_0.28.urdf"), [-0.015, 0.06, 0.14],
               [0, 0, 0.3824995, 0.9239557])

    p.resetDebugVisualizerCamera(0.5, 30, -60, [0, 0, 0])
    p.setGravity(0, 0, -10)
    self._shadow_hand = Shadow_hand.Shadow_hand(urdfRootPath=self._urdfRoot, timeStep=self._timeStep)
    self._envStepCounter = 0
    p.stepSimulation()

    self._observation = self.getExtendedObservation()
    self._observation_sum = self.get_reward_sum(self._observation)

    return np.array(self._observation)



  def getcontactinfo(self):
    points_info = []
    contact_number = []
    point_target_info_compute = []
    # todo: inde_index corresponding palm, (proximial,middle,distal)*5
    link_index_need_compute_contact = [0, 2, 3, 4, 7, 8, 9, 12, 13, 14, 18, 19, 20, 23,25, 26]
    for i in range(len(link_index_need_compute_contact)):
      contact_info=(p.getContactPoints(self._shadow_hand.shadow_hand_Uid,self._object_Uid,link_index_need_compute_contact[i],-1))
      #todo: point_target_info=[contact_number,corresponding several contact coordinates] for one link
      #todo: points_info =[all points_target_info]
      if len(contact_info)==0:
        point_target_info=[0]
      else:
        point_target_info=[len(contact_info)]
        for i in range(len(contact_info)):
          point_target_info.append(contact_info[i][5])
          #todo: point_target_infor_compyte=[corresponding contact coordinates] for all links
          point_target_info_compute.append(contact_info[i][5])
      points_info.append(point_target_info)



    #todo: contact_number=[each link contact number]
    for i in range(len(link_index_need_compute_contact)):
      contact_number.append(points_info[i][0])

    #todo: self._contactinfo collects points_info in last 10 steps
    self._contactinfo.append(points_info)
    if len(self._contactinfo)>10:
      self._contactinfo=self._contactinfo[1:]

    #todo: self._contactnumber collects all link contact number in last 10 steps
    self._contactnumber.append(contact_number)
    if len(self._contactnumber)>10:
      self._contactnumber=self._contactnumber[1:]

    #todo: self._contactinfo_compute is similarly equal to self._contactinfo, but delete the contact number of each link
    #todo: only reserve contact points coordinates in last 10 steps, it will be easy to compare differences bewteen two steps
    self._contactinfo_compute.append(point_target_info_compute)
    if len(self._contactinfo_compute)>10:
      self._contactinfo_compute=self._contactinfo_compute[1:]

    ending=False
    contactnumber_np=np.array(self._contactnumber)
    #todo:use np.sum(contact points at current step==0) to judge whether all links have been contacted or not (at most allow two links not to contact)
    if np.sum(contactnumber_np[-1]==0)<=2:
        contactinfo_compute_np=np.array(self._contactinfo_compute)
        contact_number=len(contactinfo_compute_np[-1])
        same_count=0
        #todo: judge whether the contact number is the same in last 10(len(contactinfo_compute_np) steps
        for i in range(len(contactinfo_compute_np)):
            if len(contactinfo_compute_np[i])-contact_number==0:
                same_count=same_count+1
        #todo: if contact points are stable, return ending = True
        if same_count==len(contactinfo_compute_np):
            error=0
            for i in range(len(contactinfo_compute_np)):
                error=error+np.sum(np.power(contactinfo_compute_np[i]-contactinfo_compute_np[-1],2))
            if error < 0.001:
                ending=True
            else:
                ending=False
        else: ending=False

    return self._contactinfo, self._contactnumber,ending







  def getExtendedObservation(self):
    maximum_distance=1
    distance_sum=[]
    #todo: linde_index corresponding palm, (proximial,middle,distal)*5
    link_index_need_compute_distance=[0,2,3,4,7,8,9,12,13,14,18,19,20,23,25,26]
    for i in range(len(link_index_need_compute_distance)):
      distance_sum.append(p.getClosestPoints(self._shadow_hand.shadow_hand_Uid,self._object_Uid,maximum_distance,
                                             link_index_need_compute_distance[i],-1)[0][8])

    self._observation=distance_sum
    return self._observation






  def get_reward_sum(self,distance_sum):
    sum=0
    for i in range(len(distance_sum)):
      sum=sum+distance_sum[i]
    return sum



  def step(self, action):
    for i in range(self._actionRepeat):
      self._shadow_hand.applyAction(action)
      p.stepSimulation()
      # if self._termination():
      #   break
      self._envStepCounter += 1
    if self._renders:
      time.sleep(self._timeStep)
    self._observation = self.getExtendedObservation()
    reward = self._observation_sum - self.get_reward_sum(self._observation) #todo:last time distance - now time distance
    # state=p.getLinkState(self._shadow_hand.shadow_hand_Uid,10)
    # print (state)
    self._observation_sum = self.get_reward_sum(self._observation)
    reward_done,done = self._termination()
    if done == True:
      reward=reward_done
    return np.array(self._observation), reward, done, {}

  # def render(self, mode="rgb_array", close=False):
  #   if mode != "rgb_array":
  #     return np.array([])
  #
  #   base_pos, orn = self._p.getBasePositionAndOrientation(self._shadow_hand.shadow_hand_Uid)
  #   view_matrix = self._p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=base_pos,
  #                                                           distance=self._cam_dist,
  #                                                           yaw=self._cam_yaw,
  #                                                           pitch=self._cam_pitch,
  #                                                           roll=0,
  #                                                           upAxisIndex=2)
  #   proj_matrix = self._p.computeProjectionMatrixFOV(fov=60,
  #                                                    aspect=float(RENDER_WIDTH) / RENDER_HEIGHT,
  #                                                    nearVal=0.1,
  #                                                    farVal=100.0)
  #   (_, _, px, _, _) = self._p.getCameraImage(width=RENDER_WIDTH,
  #                                             height=RENDER_HEIGHT,
  #                                             viewMatrix=view_matrix,
  #                                             projectionMatrix=proj_matrix,
  #                                             renderer=self._p.ER_BULLET_HARDWARE_OPENGL)
  #   #renderer=self._p.ER_TINY_RENDERER)
  #
  #   rgb_array = np.array(px, dtype=np.uint8)
  #   rgb_array = np.reshape(rgb_array, (RENDER_HEIGHT, RENDER_WIDTH, 4))
  #
  #   rgb_array = rgb_array[:, :, :3]
  #   return rgb_array

  def _termination(self):
    reward_done=0
    done=False
    if (self.terminated or self._envStepCounter > self._maxSteps):
      done=True
      reward_done=0
    elif p.getBasePositionAndOrientation(self._object_Uid)[0][2]<0.026:
      done=True
      reward_done=-100
    else:
      _,_,ending=self.getcontactinfo()

      if ending==True:
        p.resetBasePositionAndOrientation(self._plane_Uid, [0, 0, -0.5],[0,0,0,1])
        #todo: wait 100 loops and let object have enough time to drop down
        for i in range(100):
          p.stepSimulation()
          if self._renders:
            time.sleep(self._timeStep)
        object_present_position=p.getBasePositionAndOrientation(self._object_Uid)
        if object_present_position[0][2]>-0.2:
          reward_done=100
          done=True
      else:
        reward_done=0
        done=False
    return reward_done,done





def main():

  env = HandGymEnv(renders=True, isDiscrete=False, maxSteps=10000000)

  motorsIds = []

  dv = 1.57
  motorsIds.append(env._p.addUserDebugParameter("FFJ4", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("FFJ3", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("FFJ2", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("FFJ1", -dv, dv, 0))

  motorsIds.append(env._p.addUserDebugParameter("MFJ4", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("MFJ3", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("MFJ2", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("MFJ1", -dv, dv, 0))

  motorsIds.append(env._p.addUserDebugParameter("RFJ4", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("RFJ3", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("RFJ2", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("RFJ1", -dv, dv, 0))

  motorsIds.append(env._p.addUserDebugParameter("LFJ5", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("LFJ4", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("LFJ3", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("LFJ2", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("LFJ1", -dv, dv, 0))

  motorsIds.append(env._p.addUserDebugParameter("THJ5", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("THJ4", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("THJ3", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("THJ2", -dv, dv, 0))
  motorsIds.append(env._p.addUserDebugParameter("THJ1", -dv, dv, 0))



  done = False
  # action_intended=[0.0]*22
  # # action_intended[18]=1.57
  # # action_intended[19]=1.57
  # print (action_intended)
  # while (not done):
  #   action_intended = [0.01]*22
  #   zero_index=[0,4,8,12,13,17]
  #   for i in range(6):
  #     action_intended[zero_index[i]]=0
  #   # action_intended[1]=0
  #
  #   state, reward, done, info = env.step(action_intended)



  while (not done):
    action = []
    for motorId in motorsIds:
      action.append(env._p.readUserDebugParameter(motorId))

      points=p.getContactPoints(env._shadow_hand.shadow_hand_Uid,env._object_Uid,0,-1)
      number=len(points)
      if number == 0:
        print ('no contact point')
      else:
        for i in range(number):
          print ('contact {0} is {1}'.format(i,p.getContactPoints(env._shadow_hand.shadow_hand_Uid,env._object_Uid,0,-1)[i][7]))

    state, reward, done, info = env.step(action)
    # # obs = environment.getExtendedObservation()


if __name__ == "__main__":
  main()


