import os, inspect

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(os.path.dirname(currentdir))
os.sys.path.insert(0, parentdir)

import pybullet as p
import numpy as np
import math
import pybullet_data_zhong
import random
import time
import gym
from gym import spaces
from sympy import flatten
import random
import copy
import sys
sys.path.append("/home/henricli/PycharmProjects/Data_driven_hand_design/zhong_envs/pybullet_envs_zhong/bullet")
from urdf_constructed_function import create_hand
from grasp_quality_measurement_functions import get_friction_cone_vector, compute_force_convex_hull_function, \
    get_friction_cone_vertical_inwards_vector, get_finger_friction_cone_jocobian_grasp_matrix, \
    integrate_all_finger_jocobian_cone_grasp_matrix, get_minmum_energy_result, get_minmum_energy_result_plus_palm

RENDER_HEIGHT = 720
RENDER_WIDTH = 960


class Self_reconstructed_hand(gym.Env):
    metadata = {'render.modes': ['human', 'rgb_array'], 'video.frames_per_second': 50}

    def __init__(self,
                 urdfRootPath=pybullet_data_zhong.getDataPath(),
                 timeStep=1.0 / 240.0,
                 renders=False,
                 actionRepeat=1,
                 maxSteps=20
                 ):
        self.urdfRootPath = urdfRootPath
        self._timeStep = timeStep
        self._renders = renders
        self._actionRepeat = actionRepeat
        self._maxSteps = maxSteps
        self._observation = []
        self.maxVelocity = .35
        self.maxForceTorque = 20.
        self.useSimulation = 1
        self.useOrientation = 1
        self.fixed_base = 1
        self.fingertip_index = []
        self.link_sum = 0
        self.hand_position = [0, 0, 1]
        self.hand_oritation = [0, 0, 0, 1]
        self.finger_number = 10
        self.single_finger_joint_number = 4
        self.base_xyz = [0.06, 0.016, 0.06]
        # self.link_length_list=[0.016, 0.020, 0.024, 0.028, 0.032, 0.036, 0.040, 0.044, 0.048, 0.052]
        # self.link_length_list = [0.016, 0.021, 0.026, 0.031, 0.036, 0.041, 0.046, 0.051, 0.056, 0.062]
        # self.link_length_list = [0.016, 0.021, 0.026, 0.031, 0.036, 0.041, 0.046, 0.051, 0.056, 0.08]
        self.link_length_list = [0.016, 0.024, 0.032, 0.040, 0.048, 0.056, 0.064, 0.072, 0.080, 0.088]
        self.link_width = 0.008
        self.object_index = 2
        self.last_configuration_reward = 0
        self.current_configuration_reward = 0
        self.negative_reward = -0
        self.contact_flag_bewteen_hand_and_plane = 0

        self._p = p
        self._cam_dist = 0.4
        self._cam_yaw = 180
        self._cam_pitch = 0

        if self._renders:
            cid = p.connect(p.SHARED_MEMORY)
            if (cid < 0):
                cid = p.connect(p.GUI)
            p.resetDebugVisualizerCamera(0.5, 180, -60, [0, 0, 0])
        else:
            p.connect(p.DIRECT)

        self.seed()
        self.reset()

        action_dim = 3
        self._action_bound = 11
        action_high = np.array([self._action_bound] * action_dim)
        self.action_space = spaces.Box(-action_high, action_high)
        # print(self.action_space)

        observationDim = len(self.getExtendedObservation())
        # print ('observationDim is {0}'.format(observationDim))
        # print ('self._observation is {0}'.format(self._observation))
        observation_high = np.array([11] * observationDim)
        self.observation_space = spaces.Box(-observation_high, observation_high)

    def reset(self):
        # print ('reset Env')
        self.hand_state = [[0 for col in range(self.single_finger_joint_number * 2)] for row in
                           range(self.finger_number)]
        self.grasp_flag = 0

        # self.hand_state[0]=[1,2,10,1,10,1,10,1,0,0,0,0]
        # self.hand_state[4]=[1,2,10,1,10,1,10,1,0,0,0,0]
        # self.hand_state[5]=[1,2,10,1,10,1,10,1,0,0,0,0]
        # # self.hand_state[9]=[1,2,10,1,10,1,10,1,0,0,0,0]
        # self.hand_state[1]=[1,2,8,1,8,1,0,0]
        # self.hand_state[3]=[1,2,8,1,8,1,0,0]
        # self.hand_state[6]=[1,2,8,1,8,1,0,0]
        # self.hand_state[8]=[1,2,8,1,8,1,0,0]
        # self.hand_state[2] = [1, 2, 8, 1, 8, 1, 0, 0]
        # self.hand_state[7] = [1, 2, 8, 1, 8, 1, 0, 0]
        self.old_hand_state = copy.deepcopy(self.hand_state)
        # self.terminated = 0
        self._observation_sum = 0
        self._envStepCounter = 0
        p.resetSimulation()
        # p.setPhysicsEngineParameter(numSolverIterations=150)
        p.setTimeStep(self._timeStep)
        self.contact_flag_bewteen_hand_and_plane = 0

        PlaneId = p.createCollisionShape(p.GEOM_PLANE)
        self.plane_Uid = p.createMultiBody(0, PlaneId, -1, [0, 0, 0])

        self.urdf_file_name, self.finger_abduction_adduction_index, self.finger_abduction_adduction_in_which_side, self.finger_flex_index \
            = create_hand(self.urdfRootPath + '/hand_configuration', self.hand_state, self.base_xyz,
                          self.link_length_list, self.link_width)

        self.self_reconstructed_hand_Uid = p.loadURDF(
            os.path.join(self.urdfRootPath + '/hand_configuration', self.urdf_file_name),
            self.hand_position, self.hand_oritation, useFixedBase=1,
            flags=p.URDF_USE_SELF_COLLISION | p.URDF_USE_SELF_COLLISION_EXCLUDE_PARENT)

        self.object_Uid, central_width, central_height = self.choose_object(self.object_index)

        # print ('inital object position is {0}'.format(p.getBasePositionAndOrientation(self.object_Uid)))

        self.numJoints = p.getNumJoints(self.self_reconstructed_hand_Uid)
        self.jointPositions = [0] * self.numJoints

        # print ('reset numJoints are {0}'.format(self.numJoints))

        # todo: set hand friction
        for i in range(self.numJoints):
            p.changeDynamics(self.self_reconstructed_hand_Uid, i, lateralFriction=0.2, spinningFriction=0.001)
        p.changeDynamics(self.self_reconstructed_hand_Uid, -1, lateralFriction=0.2, spinningFriction=0.001)

        p.resetDebugVisualizerCamera(0.5, 180, -30, [0, 0, 0])
        p.setGravity(0, 0, -10)

        p.stepSimulation()
        self._observation = self.getExtendedObservation()

        # self.last_configuration_reward=self.get_current_configuration_reward(self.hand_state)
        # print ('reset reward is {0}'.format(self.last_configuration_reward))
        self.last_configuration_reward = 0
        # print ('initial last configuration reward is set to {0}'.format(self.last_configuration_reward))
        # print ('reset end')

        return np.array(self._observation)

    def choose_object(self, object_index, object_width_or_radius=0.06, object_height=0.12):
        # object_width_or_radius=0.08
        # object_height=0.12
        if object_index == 0:
            object_collision_shape = p.createCollisionShape(p.GEOM_BOX,
                                                            halfExtents=[object_width_or_radius, object_width_or_radius,
                                                                         object_height])
            object_visual_shape = p.createVisualShape(p.GEOM_BOX,
                                                      halfExtents=[object_width_or_radius, object_width_or_radius,
                                                                   object_height],
                                                      rgbaColor=[0, 0, 0, 1])
            self.object_Uid = p.createMultiBody(0.1, object_collision_shape, object_visual_shape, [0, 0, object_height])
            # p.loadURDF(os.path.join(self.urdfRootPath, "grasp_object/cuboid_width_height_1000/urdf/cuboid_width_height_1000.urdf"), [0.4, 0, 0.06],
            #            [0, 0, 0, 1])
            # p.loadURDF(os.path.join(self.urdfRootPath, "grasp_object/cone_radius_1000_degree_30/urdf/cone_radius_1000_degree_30.urdf"), [0.4, 0, 2.0/3*object_width_or_radius*math.cos(math.pi/12)],
            #            [0, 0.7930703, 0, 0.6091302],useFixedBase=1)
            central_width = object_width_or_radius * math.sqrt(2)
            central_height = object_height
        elif object_index == 1:
            object_collision_shape = p.createCollisionShape(p.GEOM_CYLINDER, radius=object_width_or_radius,
                                                            height=object_height)
            object_visual_shape = p.createVisualShape(p.GEOM_CYLINDER, radius=object_width_or_radius,
                                                      length=object_height,
                                                      rgbaColor=[0, 0, 0, 1])
            self.object_Uid = p.createMultiBody(0.1, object_collision_shape, object_visual_shape,
                                                [0, 0, object_height / 2])
            central_width = object_width_or_radius
            central_height = object_height / 2
        elif object_index == 2:
            # object_collision_shape=p.createCollisionShape(p.GEOM_SPHERE, radius=object_width_or_radius)
            # object_visual_shape = p.createVisualShape(p.GEOM_SPHERE, radius=object_width_or_radius,
            #                                           rgbaColor=[0, 0, 0, 1])
            # self.object_Uid = p.createMultiBody(0.1, object_collision_shape, object_visual_shape, [0, 0, object_width_or_radius])
            # self.object_Uid = p.loadURDF(os.path.join(self.urdfRootPath, "sphere_0.06.urdf"), [0, 0, 0.06],
            #                               [0, 0, 0, 1])
            self.object_Uid = p.loadURDF(
                os.path.join(self.urdfRootPath, "grasp_object/sphere_radius_1000/urdf/sphere_radius_1000.urdf"),
                [0, 0, 0.06], [0, 0, 0, 1])
            central_width = object_width_or_radius
            central_height = object_width_or_radius
        elif object_index == 3:
            self.object_Uid = p.loadURDF(os.path.join(self.urdfRootPath,
                                                      "grasp_object/cone_radius_1000_degree_30/urdf/cone_radius_1000_degree_30.urdf"),
                                         [0, 0, 2.0 / 3 * object_width_or_radius * math.cos(math.pi / 12)],
                                         [0, 0.7930703, 0, 0.6091302])
            central_width = object_width_or_radius
            central_height = object_width_or_radius

        return self.object_Uid, central_width, central_height

    def reset_hand_position_and_orientation(self, object_index, central_width, central_height, theta, offset=0):
        if object_index == 0:
            self.hand_oritation = p.getQuaternionFromEuler([math.pi / 2, math.pi / 2, theta])
            self.hand_position = [-(central_width + self.base_xyz[1] / 2 + offset) * math.cos(theta),
                                  -(central_width + self.base_xyz[1] / 2 + offset) * math.sin(theta), central_height]
            p.resetBasePositionAndOrientation(self.self_reconstructed_hand_Uid, self.hand_position, self.hand_oritation)
        elif object_index == 1:
            self.hand_oritation = p.getQuaternionFromEuler([math.pi / 2, math.pi / 2, theta])
            self.hand_position = [-(central_width + self.base_xyz[1] / 2 + offset) * math.cos(theta),
                                  -(central_width + self.base_xyz[1] / 2 + offset) * math.sin(theta), central_height]
            p.resetBasePositionAndOrientation(self.self_reconstructed_hand_Uid, self.hand_position, self.hand_oritation)
        elif object_index == 2:
            self.hand_oritation = p.getQuaternionFromEuler([math.pi / 2, math.pi, theta])
            self.hand_position = [0, 0, central_height * 2 + self.base_xyz[1] / 2 + offset]
            p.resetBasePositionAndOrientation(self.self_reconstructed_hand_Uid, self.hand_position, self.hand_oritation)
        elif object_index == 3:
            self.hand_oritation = p.getQuaternionFromEuler([math.pi / 2, math.pi, theta])
            self.hand_position = [0, 0, central_height * 2 + self.base_xyz[1] / 2 + offset]
            p.resetBasePositionAndOrientation(self.self_reconstructed_hand_Uid, self.hand_position, self.hand_oritation)
        p.stepSimulation()



    # def choose_inital_hand_abduction_adduction_joint_degree(self,object_index,finger_abduction_adduction_index,finger_abduction_adduction_in_which_side):
    #     if finger_abduction_adduction_index!=[] and (object_index==2 or object_index==3):
    #         joint_list = []
    #         if finger_abduction_adduction_in_which_side[-1] == -1:
    #             joint_in_side_1_number = finger_abduction_adduction_in_which_side.index(-1)
    #         elif finger_abduction_adduction_in_which_side[-1] == 1:
    #             joint_in_side_1_number = len(finger_abduction_adduction_in_which_side)
    #
    #         for i in range(len(finger_abduction_adduction_index)):
    #             joint_list.append(random.randint(-2,2))
    #         joint_list[0:joint_in_side_1_number]=sorted(joint_list[0:joint_in_side_1_number],reverse=True)
    #         joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)]=sorted(joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)])
    #
    #         for index in finger_abduction_adduction_index:
    #             self.jointPositions[index]=joint_list[finger_abduction_adduction_index.index(index)]*math.pi/6
    #         # print ('joint list is {0}'.format(joint_list))
    #         return [i*math.pi/6 for i in joint_list]
    #     elif finger_abduction_adduction_index!=[] and object_index!=2 and object_index!=3:
    #         joint_list = [0]*len(finger_abduction_adduction_index)
    #         return joint_list
    #
    #     else:
    #         return []

    def choose_inital_hand_abduction_adduction_joint_degree(self, object_index, finger_abduction_adduction_index,
                                                            finger_abduction_adduction_in_which_side):
        if finger_abduction_adduction_index != [] and (object_index == 2 or object_index == 3):
            joint_list = []
            abduction_index_in_which_finger = []
            for i in range(self.finger_number):
                if self.hand_state[i][1] == 2:
                    abduction_index_in_which_finger.append(i + 1)


            # todo:when each side has adbuction freedom
            if finger_abduction_adduction_in_which_side[-1] == -1:
                joint_in_side_1_number = finger_abduction_adduction_in_which_side.index(-1)
                joint_in_side_plus_1_number = len(finger_abduction_adduction_in_which_side) - joint_in_side_1_number
                # print ('1 side number is {0}'.format(joint_in_side_1_number))


                if joint_in_side_1_number == 1:
                    if abduction_index_in_which_finger[0] <= 2:
                        joint_list[0:joint_in_side_1_number] = [math.pi / 4]
                    elif abduction_index_in_which_finger[0] == 3:
                        joint_list[0:joint_in_side_1_number] = [0.0]
                    elif abduction_index_in_which_finger[0] >= 4:
                        joint_list[0:joint_in_side_1_number] = [-math.pi / 4]
                elif joint_in_side_1_number == 2:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 4, -math.pi / 4]
                elif joint_in_side_1_number == 3:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 4, 0.0, -math.pi / 4]
                elif joint_in_side_1_number == 4:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 3, math.pi / 6, -math.pi / 6, -math.pi / 3]
                elif joint_in_side_1_number == 5:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 3, math.pi / 6, 0.0, -math.pi / 6, -math.pi / 3]

                if joint_in_side_plus_1_number == 1:
                    if abduction_index_in_which_finger[joint_in_side_1_number] <= 7:
                        joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)] = [-math.pi / 4]
                    elif abduction_index_in_which_finger[joint_in_side_1_number] == 8:
                        joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)] = [0.0]
                    elif abduction_index_in_which_finger[joint_in_side_1_number] >= 9:
                        joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)] = [math.pi / 4]
                elif joint_in_side_plus_1_number == 2:
                    joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)] = [-math.pi / 4,
                                                                                                math.pi / 4]
                elif joint_in_side_plus_1_number == 3:
                    joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)] = [-math.pi / 4, 0.0,
                                                                                                math.pi / 4]
                elif joint_in_side_plus_1_number == 4:
                    joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)] = [-math.pi / 3,
                                                                                                -math.pi / 6,
                                                                                                math.pi / 6,
                                                                                                math.pi / 3]
                elif joint_in_side_plus_1_number == 5:
                    joint_list[joint_in_side_1_number:len(finger_abduction_adduction_index)] = [-math.pi / 3,
                                                                                                -math.pi / 6, 0.0,
                                                                                                math.pi / 6,
                                                                                                math.pi / 3]

            # todo:when only side 1 has adbuction freedom
            elif finger_abduction_adduction_in_which_side[-1] == 1:
                joint_in_side_1_number = len(finger_abduction_adduction_in_which_side)
                if joint_in_side_1_number == 1:
                    if abduction_index_in_which_finger[0] <= 2:
                        joint_list[0:joint_in_side_1_number] = [math.pi / 4]
                    elif abduction_index_in_which_finger[0] == 3:
                        joint_list[0:joint_in_side_1_number] = [0.0]
                    elif abduction_index_in_which_finger[0] >= 4:
                        joint_list[0:joint_in_side_1_number] = [-math.pi / 4]
                elif joint_in_side_1_number == 2:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 4, -math.pi / 4]
                elif joint_in_side_1_number == 3:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 4, 0.0, -math.pi / 4]
                elif joint_in_side_1_number == 4:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 3, math.pi / 6, -math.pi / 6, -math.pi / 3]
                elif joint_in_side_1_number == 5:
                    joint_list[0:joint_in_side_1_number] = [math.pi / 3, math.pi / 6, 0.0, -math.pi / 6, -math.pi / 3]

            for index in finger_abduction_adduction_index:
                self.jointPositions[index] = joint_list[finger_abduction_adduction_index.index(index)]
            return joint_list

        elif finger_abduction_adduction_index != [] and object_index != 2 and object_index != 3:
            joint_list = [0] * len(finger_abduction_adduction_index)
            return joint_list

        else:
            return []

    # def power_grasp_planner(self, friction_coefficient, object_gravity, limit_torque_limit, central_width,
    #                         object_index,joint_speed=0.3):
    #     for i in range(150):
    #         distance = \
    #         p.getClosestPoints(self.self_reconstructed_hand_Uid, self.object_Uid, 100, len(self.finger_flex_index)
    #                            + len(self.finger_abduction_adduction_index) - 1, -1)[0][8]
    #         palm_contact_flag = len(p.getContactPoints(self.self_reconstructed_hand_Uid, self.object_Uid, -1, -1))
    #         if distance > 0.003 or palm_contact_flag == 0:
    #             # self.apply_finegrs_action_incremental(0.15,self.finger_flex_index)
    #             # self.apply_fingers_action_absolute(self.finger_abduction_adduction_initial_degree,self.finger_abduction_adduction_index)
    #             # todo:let every finger has similar grasp velocity even though they have different numbers of joints
    #             index_number = 0
    #             motorCommand = [joint_speed] * len(self.finger_flex_index)
    #             for number in self.hand_flex_number_list:
    #                 motorCommand[index_number:index_number + number] = [joint_speed / number] * number
    #                 index_number = index_number + number
    #             self.apply_finegrs_action_incremental_for_commands(motorCommand, self.finger_flex_index)
    #             self.apply_fingers_action_absolute(self.finger_abduction_adduction_initial_degree,
    #                                                self.finger_abduction_adduction_index)
    #         else:
    #             index_number = 0
    #             motorCommand = [joint_speed] * len(self.finger_flex_index)
    #             for number in self.hand_flex_number_list:
    #                 motorCommand[index_number:index_number + number] = [joint_speed / number / 10] * number
    #                 index_number = index_number + number
    #             self.apply_finegrs_action_incremental_for_commands(motorCommand, self.finger_flex_index)
    #             self.apply_fingers_action_absolute(self.finger_abduction_adduction_initial_degree,
    #                                                self.finger_abduction_adduction_index)
    #         p.stepSimulation()
    #         # time.sleep(self._timeStep)
    #
    #     # #todo: if finger is too long, let self.contact_flag_between_hand_and_plane equal to 1. this variable will be used in _termination
    #     # for index in self.finger_flex_index:
    #     #     contact=p.getContactPoints(self.self_reconstructed_hand_Uid,self.plane_Uid,index,-1)
    #     #     if len(contact)!=0:
    #     #         self.contact_flag_bewteen_hand_and_plane=1
    #
    #
    #     # force_convex_hull_distance_reward=self.get_force_convex_hull_minimum_distance(friction_coefficient,central_width)
    #     # if force_convex_hull_distance_reward==-1:
    #     #     energy_reward=-1
    #     # else:
    #     #     energy_reward=self.get_robotic_hand_minimum_energy(self.hand_state,friction_coefficient,object_gravity,limit_torque_limit)
    #     #
    #     # #todo:because force_convex_hull_distance_reward is on the order of 0.001, and the energy is on the order of 0.0001
    #     # #todo:we want to resize them to the order of 1, so force_convex_hull_distance_reward*1000, -energy_reward*1000
    #     # if force_convex_hull_distance_reward!=-1:
    #     #     force_convex_hull_distance_reward=force_convex_hull_distance_reward*1000
    #     # if energy_reward!=-1:
    #     #     energy_reward=-energy_reward*1000
    #     # if force_convex_hull_distance_reward==-1:
    #     #     force_convex_hull_distance_reward=self.negative_reward
    #     # if energy_reward==-1:
    #     #     energy_reward=self.negative_reward
    #
    #     # object_stop_position=p.getBasePositionAndOrientation(self.object_Uid)[0]
    #     # p.resetBasePositionAndOrientation(self.plane_Uid,[0,0,-0.1],[0,0,0,1])
    #     # for i in range(10):
    #     #     p.stepSimulation()
    #     #     time.sleep(self._timeStep)
    #     # object_stop_position_now=p.getBasePositionAndOrientation(self.object_Uid)[0]
    #
    #     # for i in range(1000):
    #     #     p.stepSimulation()
    #
    #     if object_index==2:
    #         contact_number = 0
    #         for i in range(self.numJoints + 1):
    #             contact = p.getContactPoints(self.self_reconstructed_hand_Uid, self.object_Uid, i - 1, -1)
    #             contact_number = contact_number + len(contact)
    #
    #
    #         # todo:judge whether object is grasped or not, use force convex hull to judge whether the grasp is stable or not
    #         object_and_plane_contact = p.getContactPoints(self.object_Uid, self.plane_Uid, -1, -1)
    #         if len(object_and_plane_contact) == 0 and contact_number >= 3:
    #             force_convex_hull_distance_reward = self.get_force_convex_hull_minimum_distance(friction_coefficient,
    #                                                                                             central_width)
    #             if force_convex_hull_distance_reward > 0.0006:
    #                 force_convex_hull_distance_reward = 1000
    #                 energy_reward = 1000
    #             else:
    #                 force_convex_hull_distance_reward = -1000
    #                 energy_reward = -1000
    #         else:
    #             force_convex_hull_distance_reward = -1000
    #             energy_reward = -1000
    #
    #     elif object_index==0 or object_index==1:
    #         force_convex_hull_distance_reward=self.get_force_convex_hull_minimum_distance(friction_coefficient,central_width)
    #         if force_convex_hull_distance_reward!=-1:
    #             force_convex_hull_distance_reward = 1000
    #             energy_reward = 1000
    #         elif force_convex_hull_distance_reward==-1:
    #             force_convex_hull_distance_reward=-1000
    #             energy_reward=-1000
    #
    #     return force_convex_hull_distance_reward, energy_reward

    def power_grasp_planner(self, friction_coefficient, object_gravity, limit_torque_limit, central_width,
                            object_index,joint_speed=2):

        contact_finger_list = [0] * len(self.hand_flex_number_list)
        index_number = 0
        motorCommand = [joint_speed] * len(self.finger_flex_index)
        for number in self.hand_flex_number_list:
            motorCommand[index_number:index_number + number] = [joint_speed / number] * number
            index_number = index_number + number


        self.apply_fingers_action_absolute(self.finger_abduction_adduction_initial_degree,
                                               self.finger_abduction_adduction_index)
        p.stepSimulation()

        #todo: let all finger rotate at most 120 degrees. 120/180*3.14=2 . and add 10 steps to interference grasp.
        max_step=int(20/joint_speed)+10
        for step_number in range(max_step):
            finger_flex_index_count = 0
            current_finger_index=0
            #todo: check states of each finger
            for current_finger_link_number in self.hand_flex_number_list:
                current_finger_contact_number = 0
                distance_list=[]
                #todo: compute current finger's contact and distance bewteen fingertip and
                for i in range(finger_flex_index_count,finger_flex_index_count+current_finger_link_number):
                    contact = p.getContactPoints(self.self_reconstructed_hand_Uid,self.object_Uid,self.finger_flex_index[i],-1)
                    current_finger_contact_number=current_finger_contact_number+len(contact)
                    distance = p.getClosestPoints(self.self_reconstructed_hand_Uid, self.object_Uid, 100,
                                           self.finger_flex_index[i],-1)[0][8]
                    distance_list.append(distance)

                min_distance=min(distance_list)
                # min_distance = \
                #     p.getClosestPoints(self.self_reconstructed_hand_Uid,self.object_Uid,100,
                #                        self.finger_flex_index[finger_flex_index_count + current_finger_link_number-1],
                #                                                 -1)[0][8]
                if min_distance < 0.001 and contact_finger_list[current_finger_index] == 0:
                    # print ('min')
                    for i in range(finger_flex_index_count,finger_flex_index_count+current_finger_link_number):
                        motorCommand[i]=joint_speed/current_finger_link_number/10
                if current_finger_contact_number > 0:
                    for i in range(finger_flex_index_count,finger_flex_index_count+current_finger_link_number):
                        motorCommand[i] = 0
                    contact_finger_list[current_finger_index]=1

                finger_flex_index_count = finger_flex_index_count + current_finger_link_number
                current_finger_index = current_finger_index + 1
            self.apply_finegrs_action_incremental_for_commands(motorCommand, self.finger_flex_index)
            if motorCommand == [0]*len(self.finger_flex_index):
                # print ('step number is {0}'.format(step_number))
                break
            p.stepSimulation()
            # time.sleep(self._timeStep)

        # time.sleep(1)

        for i in range(50):
            index_number=0
            motorCommand = [joint_speed] * len(self.finger_flex_index)

            for number in self.hand_flex_number_list:
                motorCommand[index_number:index_number + number] = [joint_speed / number / 10] * number
                index_number = index_number + number


            # print (motorCommand)
            self.apply_finegrs_action_incremental_for_commands(motorCommand, self.finger_flex_index)
            p.stepSimulation()
            # time.sleep(self._timeStep)

            contact_palm=p.getContactPoints(self.self_reconstructed_hand_Uid,self.object_Uid,-1,-1)
            if len(contact_palm)!=0:
                # print ("current is {0}".format(i))
                break

        # contact
        # for i in range(self.numJoints):
        #     contact=p.getContactPoints(self.self_reconstructed_hand_Uid,self.object_Uid,i,-1)


        if object_index==2:
            # print ('object index is {0}'.format(object_index))
            contact_number = 0
            for i in range(self.numJoints + 1):
                contact = p.getContactPoints(self.self_reconstructed_hand_Uid, self.object_Uid, i - 1, -1)
                contact_number = contact_number + len(contact)



            # todo:judge whether object is grasped or not, use force convex hull to judge whether the grasp is stable or not
            object_and_plane_contact = p.getContactPoints(self.object_Uid, self.plane_Uid, -1, -1)

            # print ('contact plane is {0} number'.format(len(object_and_plane_contact)))
            # print ('contact number is {0}'.format(contact_number))
            if len(object_and_plane_contact) == 0 and contact_number >= 3:

                # print ('force_convex_hull_distance_reward is {0}'.format(force_convex_hull_distance_reward))
                if len(contact_palm)!=0:
                    # print ('force convex hull distance is {0}'.format(force_convex_hull_distance_reward))
                    grasp_reward=1000
                    force_convex_hull_distance_reward = self.get_force_convex_hull_minimum_distance(friction_coefficient,
                                                                                central_width)
                    force_convex_hull_distance_reward = force_convex_hull_distance_reward*600000
                    energy_reward = 0
                else:
                    grasp_reward=0
                    force_convex_hull_distance_reward = 0
                    energy_reward = 0
            else:
                grasp_reward = 0
                force_convex_hull_distance_reward = 0
                energy_reward = 0

        elif object_index==0 or object_index==1:
            # print ('object index is {0}'.format(object_index))
            force_convex_hull_distance_reward=self.get_force_convex_hull_minimum_distance(friction_coefficient,central_width)
            # print('force convex hull distance is {0}'.format(force_convex_hull_distance_reward))
            if force_convex_hull_distance_reward!=-1:
                grasp_reward = 1000
                force_convex_hull_distance_reward = force_convex_hull_distance_reward * 600000
                energy_reward = 0
            elif force_convex_hull_distance_reward==-1:
                grasp_reward = 0
                force_convex_hull_distance_reward = 0
                energy_reward = 0

        # contact_number=0
        # for i in range(self.numJoints + 1):
        #     contact = p.getContactPoints(self.self_reconstructed_hand_Uid, self.object_Uid, i - 1, -1)
        #     contact_number = contact_number + len(contact)
        # print ('contact_number is {0}'.format(contact_number))


        return grasp_reward, force_convex_hull_distance_reward, energy_reward

    def apply_finegrs_action_incremental(self, motorCommand, motorIndices):
        # todo: motorCommands is current joint states - last time joint states
        current_states_all = p.getJointStates(self.self_reconstructed_hand_Uid, motorIndices)
        for i in range(len(motorIndices)):
            p.setJointMotorControl2(self.self_reconstructed_hand_Uid,
                                    motorIndices[i],
                                    p.POSITION_CONTROL,
                                    targetPosition=current_states_all[i][0] + motorCommand,
                                    force=self.maxForceTorque)

    # def apply_finegrs_action_incremental_for_commands(self, motorCommand, motorIndices):
    #     # todo: motorCommands is current joint states - last time joint states
    #     current_states_all = p.getJointStates(self.self_reconstructed_hand_Uid, motorIndices)
    #     for i in range(len(motorIndices)):
    #         p.setJointMotorControl2(self.self_reconstructed_hand_Uid,
    #                                 motorIndices[i],
    #                                 p.POSITION_CONTROL,
    #                                 targetPosition=current_states_all[i][0] + motorCommand[i],
    #                                 force=self.maxForceTorque)

    def apply_finegrs_action_incremental_for_commands(self, motorCommand, motorIndices):
        # todo: motorCommands is current joint states - last time joint states
        current_states_all = p.getJointStates(self.self_reconstructed_hand_Uid, motorIndices)
        motorPosition=[]
        for i in range(len(motorIndices)):
            motorPosition.append(current_states_all[i][0] + motorCommand[i])


        p.setJointMotorControlArray(self.self_reconstructed_hand_Uid,
                                    motorIndices,
                                    p.POSITION_CONTROL,
                                    targetPositions=motorPosition,
                                    forces=[self.maxForceTorque]*len(motorIndices))

    # def apply_fingers_action_absolute(self, motorCommand, motorIndices):
    #     for i in range(len(motorIndices)):
    #         p.setJointMotorControl2(self.self_reconstructed_hand_Uid,
    #                                 motorIndices[i],
    #                                 p.POSITION_CONTROL,
    #                                 targetPosition=motorCommand[i],
    #                                 force=self.maxForceTorque)

    def apply_fingers_action_absolute(self, motorCommand, motorIndices):
        motorPosition=[]
        for i in range(len(motorIndices)):
            motorPosition.append(motorCommand[i])

        p.setJointMotorControlArray(self.self_reconstructed_hand_Uid,
                                    motorIndices,
                                    p.POSITION_CONTROL,
                                    targetPositions=motorPosition,
                                    forces=[self.maxForceTorque]*len(motorIndices))

    def get_force_convex_hull_minimum_distance(self, friction_coefficient, central_width):
        # start_time=time.time()
        contact_position = []
        contact_normal = []
        # todo:because we should collect the contact points from the plam, the index should begin with -1
        for i in range(self.numJoints + 1):
            # todo:Note, this contact normal direction is towards to object!!!
            contact = p.getContactPoints(self.object_Uid, self.self_reconstructed_hand_Uid, -1, i - 1)
            # print ('link {0} has {1} points'.format(i-1,len(contact)))
            for j in range(len(contact)):
                contact_position.append(contact[j][5])
                contact_normal.append(contact[j][7])
                # p.addUserDebugLine(contact[j][5],[contact[j][5][0]-contact[j][7][0],contact[j][5][1]-contact[j][7][1],
                #                                   contact[j][5][2]-contact[j][7][2]],[0.0,0.0,1.0],lineWidth=1.0,lifeTime=100)

        object_position = p.getBasePositionAndOrientation(self.object_Uid)[0]
        # print ('draw line time is {0}'.format(time.time()-start_time))

        if len(contact_position) == 0:
            # print ('The robotic hand did not grasp anything')

            force_convex_hull_distance_reward = -1
        else:
            # print ('total contact point number is {0}'.format(len(contact_position)))
            # start_time=time.time()
            for i in range(len(contact_position)):
                contact_plus_object_position = np.array(contact_position[i]) - np.array(object_position)
                cross_matrix_about_contact_plus_object_position = np.array(
                    [[0, -contact_plus_object_position[2], contact_plus_object_position[1]],
                     [contact_plus_object_position[2], 0, -contact_plus_object_position[0]],
                     [-contact_plus_object_position[1], contact_plus_object_position[0], 0]])

                # todo:wrench is a 6-vector, 3-vetor is force,3-vector is torque. In order to unify dimension, the force should multiply distance
                friction_cone_four_forces = get_friction_cone_vector(contact_normal[i],
                                                                     friction_coefficient) * central_width
                four_torques = np.dot(cross_matrix_about_contact_plus_object_position, friction_cone_four_forces)
                four_wrenches = np.vstack((friction_cone_four_forces, four_torques))
                if i == 0:
                    force_convex_hull_points = four_wrenches.T
                else:
                    force_convex_hull_points = np.vstack((force_convex_hull_points, four_wrenches.T))
            # print ('get points time is {0}'.format(time.time()-start_time))

            # print ('force_convex_hull_points_number is {0}'.format(len(force_convex_hull_points)))

            force_convex_hull_distance_reward = compute_force_convex_hull_function(force_convex_hull_points)
        # print ('force_convex_hull_distance_reward is {0}'.format(force_convex_hull_distance_reward))
        return force_convex_hull_distance_reward

    def get_robotic_hand_minimum_energy(self, handstate, friction_coefficient, W_g, joint_torque_limit):
        contact_position_all = []
        contact_normal_vector_all = []
        joint_position_all = []
        joint_orientation_all = []
        current_index = 0
        for i in range(len(handstate)):
            if handstate[i][-1] == 0:
                link_number = int(handstate[i].index(0) / 2)
            else:
                link_number = self.single_finger_joint_number
            contact_position = []
            contact_normal_vector = []
            joint_position = []
            joint_orientation = []
            for j in range(link_number):
                contact_position_link = []
                contact_normal_vector_link = []
                contact = p.getContactPoints(self.self_reconstructed_hand_Uid, self.object_Uid, current_index + j, -1)
                for k in range(len(contact)):
                    contact_position_link.append(contact[k][5])
                    contact_normal_vector_link.append(contact[k][7])
                contact_position.append(contact_position_link)
                contact_normal_vector.append(contact_normal_vector_link)
                joint_position.append(p.getLinkState(self.self_reconstructed_hand_Uid, current_index + j)[0])
                joint_aixs_orientation = np.dot(np.array(p.getMatrixFromQuaternion(
                    p.getLinkState(self.self_reconstructed_hand_Uid, current_index + j)[1])).reshape(3, 3),
                                                np.array(
                                                    p.getJointInfo(self.self_reconstructed_hand_Uid, current_index + j)[
                                                        13]).reshape(-1, 1))

                joint_orientation.append(
                    (joint_aixs_orientation[0][0], joint_aixs_orientation[1][0], joint_aixs_orientation[2][0]))
                # #todo: draw joint axis
                # p.addUserDebugLine(joint_position[-1],
                #                    [joint_position[-1][0] - joint_orientation[-1][0], joint_position[-1][1] - joint_orientation[-1][1],
                #                     joint_position[-1][2] - joint_orientation[-1][2]], [0.0, 1.0, 0.0], lineWidth=1.0, lifeTime=100)

            current_index = current_index + link_number
            contact_position_all.append(contact_position)
            contact_normal_vector_all.append(contact_normal_vector)
            joint_position_all.append(joint_position)
            joint_orientation_all.append(joint_orientation)

        object_position = p.getBasePositionAndOrientation(self.object_Uid)[0]
        N, J, G, link_number_sum, contact_number_sum = \
            integrate_all_finger_jocobian_cone_grasp_matrix(contact_position_all, contact_normal_vector_all,
                                                            joint_position_all,
                                                            joint_orientation_all, object_position,
                                                            friction_coefficient)

        # todo:Attension!!! Please add palm contact to G and N!!!
        contact = p.getContactPoints(self.self_reconstructed_hand_Uid, self.object_Uid, -1, -1)
        palm_contact_number = len(contact)
        palm_contact_normal_vector = []
        palm_contact_position = []
        for i in range(palm_contact_number):
            palm_contact_position.append(contact[i][5])
            palm_contact_normal_vector.append(contact[i][7])

        # print ('palm_contact_number is {0}'.format(palm_contact_number))
        N_palm = np.zeros([4 * palm_contact_number, 3 * palm_contact_number])
        for i in range(palm_contact_number):
            N_palm[i * 4:i * 4 + 4, i * 3:i * 3 + 3] = get_friction_cone_vertical_inwards_vector(
                palm_contact_normal_vector[i], friction_coefficient).T

        G_palm = np.zeros([6, palm_contact_number * 3])
        for i in range(palm_contact_number):
            G_palm[0:3, i * 3:i * 3 + 3] = np.eye(3)
            contact_plus_object_position = np.array(palm_contact_position[i]) - np.array(object_position)
            G_palm[3:6, i * 3:i * 3 + 3] = np.array(
                [[0, -contact_plus_object_position[2], contact_plus_object_position[1]],
                 [contact_plus_object_position[2], 0, -contact_plus_object_position[0]],
                 [-contact_plus_object_position[1], contact_plus_object_position[0], 0]])

        # todo:Attension, because the fi direction is toward to the robotic hand, if we use the same fi to compute object wrench, we must
        # todo: add - in fornt of G, so G should be -G
        G_palm = -G_palm

        # todo:Attension!!! Please add palm contact to G and N!!! in other words, please consider palm contact constraints
        W_g = [0, 0, -W_g, 0, 0, 0]
        joint_torque_limit = [joint_torque_limit] * link_number_sum
        # print ('contact number is {0}'.format(contact_number_sum+palm_contact_number))
        if contact_number_sum != 0 and palm_contact_number == 0:
            energy_reward = get_minmum_energy_result(N, J, G, contact_number_sum, W_g, joint_torque_limit)
        elif contact_number_sum != 0 and palm_contact_number != 0:
            energy_reward = get_minmum_energy_result_plus_palm(N, J, G, contact_number_sum, W_g,
                                                               joint_torque_limit, palm_contact_number, N_palm, G_palm)
        else:
            energy_reward = -1
        # print ('energy_reward is {0}'.format(energy_reward))
        return energy_reward

    def get_all_reward_for_one_hand_configuration(self, object_index_number_list, friction_coefficient, object_gravity,
                                                  limit_torque_limit):
        grasp_reward_list = []
        force_convex_hull_distance_reward_list = []
        energy_reward_list = []

        # todo:to record how many flex joints in each finger
        self.hand_flex_number_list = []
        for i in range(self.finger_number):
            if self.hand_state[i][-1] != 0 and self.hand_state[i][1] == 2:
                self.hand_flex_number_list.append(self.single_finger_joint_number - 1)
            elif self.hand_state[i][-1] != 0 and self.hand_state[i][1] == 1:
                self.hand_flex_number_list.append(self.single_finger_joint_number)
            elif self.hand_state[i][-1] == 0 and self.hand_state[i][0] != 0:
                if int(self.hand_state[i].index(0) / 2) - self.hand_state[i][1] + 1 != 0:
                    self.hand_flex_number_list.append(int(self.hand_state[i].index(0) / 2) - self.hand_state[i][1] + 1)

        for i in object_index_number_list:
            if i == 0:
                # print('grasped object is cuboid')
                grasp_reward_temporary_list=[]
                force_convex_hull_distance_reward_temporary_list = []
                energy_reward_temporary_list = []
                # print ('grasped object is cuboid')
                try:
                    p.removeBody(self.object_Uid)
                except:
                    # print ('No self.object_Uid')
                    None
                self.object_index = i
                self.object_Uid, central_width, central_height = self.choose_object(self.object_index)
                for theta in [0, -math.pi / 4]:
                    # print ('theta is {0}'.format(theta))
                    for offset in [0.0]:
                        grasp_reward,force_convex_hull_distance_reward, energy_reward=0,0,0
                        for q in range(4):
                            if q==0:
                                p.resetBasePositionAndOrientation(self.object_Uid, [-0.005, 0, central_height], [0, 0, 0, 1])
                            elif q==1:
                                p.resetBasePositionAndOrientation(self.object_Uid, [0.005, 0, central_height], [0, 0, 0, 1])
                            elif q==2:
                                p.resetBasePositionAndOrientation(self.object_Uid, [0, 0.005, central_height], [0, 0, 0, 1])
                            elif q==3:
                                p.resetBasePositionAndOrientation(self.object_Uid, [0, -0.005, central_height], [0, 0, 0, 1])
                        # p.resetBasePositionAndOrientation(self.object_Uid, [0, 0, central_height], [0, 0, 0, 1])
                            for j in range(self.numJoints):
                                p.resetJointState(self.self_reconstructed_hand_Uid, j, 0)
                            self.reset_hand_position_and_orientation(self.object_index, central_width, central_height,
                                                                     theta, offset)
                            self.finger_abduction_adduction_initial_degree = \
                                self.choose_inital_hand_abduction_adduction_joint_degree(self.object_index,
                                                                                         self.finger_abduction_adduction_index,
                                                                                         self.finger_abduction_adduction_in_which_side)
                            grasp_reward_q, force_convex_hull_distance_reward_q, energy_reward_q = self.power_grasp_planner(
                                friction_coefficient, object_gravity, limit_torque_limit, central_width,self.object_index)
                            grasp_reward=grasp_reward+grasp_reward_q
                            force_convex_hull_distance_reward=force_convex_hull_distance_reward+force_convex_hull_distance_reward_q
                            energy_reward=energy_reward+energy_reward_q

                        grasp_reward_temporary_list.append(grasp_reward)
                        force_convex_hull_distance_reward_temporary_list.append(force_convex_hull_distance_reward)
                        energy_reward_temporary_list.append(energy_reward)
                        if grasp_reward==4000:
                            break
                    if grasp_reward==4000:
                        break

                # print ('force_convex_hull_distance_reward_temporary_list is {0}'.format(force_convex_hull_distance_reward_temporary_list))
                grasp_reward_list.append(sorted(grasp_reward_temporary_list,reverse=True)[0])
                force_convex_hull_distance_reward_list.append(
                    sorted(force_convex_hull_distance_reward_temporary_list, reverse=True)[0])
                energy_reward_list.append(sorted(energy_reward_temporary_list, reverse=True)[0])
                # todo: if hand cannot grasp cuboid, we regard this hand cannot grasp other things
                if force_convex_hull_distance_reward_list[-1] == self.negative_reward:
                    for k in object_index_number_list[object_index_number_list.index(i) + 1:]:
                        grasp_reward_list.append(self.negative_reward)
                        force_convex_hull_distance_reward_list.append(self.negative_reward)
                        energy_reward_list.append(self.negative_reward)
                    break
            if i == 1:
                # print('grasped object is cylinder')
                grasp_reward_temporary_list=[]
                force_convex_hull_distance_reward_temporary_list = []
                energy_reward_temporary_list = []
                try:
                    p.removeBody(self.object_Uid)
                except:
                    # print ('No self.object_Uid')
                    None
                self.object_index = i
                self.object_Uid, central_width, central_height = self.choose_object(self.object_index)
                theta = 0
                for offset in [0.0]:
                    grasp_reward,force_convex_hull_distance_reward, energy_reward=0,0,0
                    for q in range(4):
                        if q==0:
                            p.resetBasePositionAndOrientation(self.object_Uid, [-0.005, 0, central_height], [0, 0, 0, 1])
                        elif q==1:
                            p.resetBasePositionAndOrientation(self.object_Uid, [0.005, 0, central_height], [0, 0, 0, 1])
                        elif q==2:
                            p.resetBasePositionAndOrientation(self.object_Uid, [0, 0.005, central_height], [0, 0, 0, 1])
                        elif q==3:
                            p.resetBasePositionAndOrientation(self.object_Uid, [0, -0.005, central_height], [0, 0, 0, 1])
                    # p.resetBasePositionAndOrientation(self.object_Uid, [0, 0, central_height], [0, 0, 0, 1])
                        for j in range(self.numJoints):
                            p.resetJointState(self.self_reconstructed_hand_Uid, j, 0)
                        self.reset_hand_position_and_orientation(self.object_index, central_width, central_height, theta,
                                                                 offset)
                        self.finger_abduction_adduction_initial_degree = \
                            self.choose_inital_hand_abduction_adduction_joint_degree(self.object_index,
                                                                                     self.finger_abduction_adduction_index,
                                                                                     self.finger_abduction_adduction_in_which_side)
                        grasp_reward_q,force_convex_hull_distance_reward_q, energy_reward_q = self.power_grasp_planner(friction_coefficient,
                                                                                                    object_gravity,
                                                                                                    limit_torque_limit,
                                                                                                    central_width,self.object_index)
                        grasp_reward=grasp_reward+grasp_reward_q
                        force_convex_hull_distance_reward=force_convex_hull_distance_reward+force_convex_hull_distance_reward_q
                        energy_reward=energy_reward+energy_reward_q

                    grasp_reward_temporary_list.append(grasp_reward)
                    force_convex_hull_distance_reward_temporary_list.append(force_convex_hull_distance_reward)
                    energy_reward_temporary_list.append(energy_reward)
                    # if force_convex_hull_distance_reward == 1000:
                    #     break

                grasp_reward_list.append(sorted(grasp_reward_temporary_list,reverse=True)[0])
                force_convex_hull_distance_reward_list.append(
                    sorted(force_convex_hull_distance_reward_temporary_list, reverse=True)[0])
                energy_reward_list.append(sorted(energy_reward_temporary_list, reverse=True)[0])
                if force_convex_hull_distance_reward_list[-1] == self.negative_reward:
                    for k in object_index_number_list[object_index_number_list.index(i) + 1:]:
                        grasp_reward_list.append(self.negative_reward)
                        force_convex_hull_distance_reward_list.append(self.negative_reward)
                        energy_reward_list.append(self.negative_reward)
                    break
            if i == 2:
                # print('grasped object is sphere')
                grasp_reward_temporary_list=[]
                force_convex_hull_distance_reward_temporary_list = []
                energy_reward_temporary_list = []
                try:
                    p.removeBody(self.object_Uid)
                except:
                    # print ('No self.object_Uid')
                    None
                self.object_index = i
                self.object_Uid, central_width, central_height = self.choose_object(self.object_index)
                theta = 0
                for offset in [0.005, 0.02, 0.04]:
                    # print ('offset is {0}'.format(offset))
                    # random_sample_number=1+len(self.finger_abduction_adduction_index)*3
                    # print ('random_sample_number is {0}'.format(random_sample_number))
                    grasp_reward,force_convex_hull_distance_reward, energy_reward=0,0,0
                    for q in range(4):
                        if q==0:
                            p.resetBasePositionAndOrientation(self.object_Uid, [-0.005, 0, central_height], [0, 0, 0, 1])
                        elif q==1:
                            p.resetBasePositionAndOrientation(self.object_Uid, [0.005, 0, central_height], [0, 0, 0, 1])
                        elif q==2:
                            p.resetBasePositionAndOrientation(self.object_Uid, [0, 0.005, central_height], [0, 0, 0, 1])
                        elif q==3:
                            p.resetBasePositionAndOrientation(self.object_Uid, [0, -0.005, central_height], [0, 0, 0, 1])
                        
                        for j in range(self.numJoints):
                            p.resetJointState(self.self_reconstructed_hand_Uid, j, 0)
                        self.reset_hand_position_and_orientation(self.object_index, central_width, central_height,
                                                                 theta,
                                                                 offset)
                        self.finger_abduction_adduction_initial_degree = \
                            self.choose_inital_hand_abduction_adduction_joint_degree(self.object_index,
                                                                                     self.finger_abduction_adduction_index,
                                                                                     self.finger_abduction_adduction_in_which_side)
                        # print ('finger_abduction_adduction_initial_degree is {0}'.format(self.finger_abduction_adduction_initial_degree))
                        grasp_reward_q,force_convex_hull_distance_reward_q, energy_reward_q = self.power_grasp_planner(
                            friction_coefficient, object_gravity, limit_torque_limit, central_width,self.object_index)
                        grasp_reward=grasp_reward+grasp_reward_q
                        force_convex_hull_distance_reward=force_convex_hull_distance_reward+force_convex_hull_distance_reward_q
                        energy_reward=energy_reward+energy_reward_q

                    grasp_reward_temporary_list.append(grasp_reward)
                    force_convex_hull_distance_reward_temporary_list.append(force_convex_hull_distance_reward)
                    energy_reward_temporary_list.append(energy_reward)
                    if grasp_reward_temporary_list[-1]==4000:
                        break

                grasp_reward_list.append(sorted(grasp_reward_temporary_list,reverse=True)[0])
                force_convex_hull_distance_reward_list.append(
                    sorted(force_convex_hull_distance_reward_temporary_list, reverse=True)[0])
                energy_reward_list.append(sorted(energy_reward_temporary_list, reverse=True)[0])
                # print ('force_convex_hull_distance_reward_list[-1] is {0}'.format(force_convex_hull_distance_reward_list[-1]))
                if force_convex_hull_distance_reward_list[-1] == self.negative_reward:
                    for k in object_index_number_list[object_index_number_list.index(i) + 1:]:
                        grasp_reward_list.append(self.negative_reward)
                        force_convex_hull_distance_reward_list.append(self.negative_reward)
                        energy_reward_list.append(self.negative_reward)
                    break
            if i == 3:
                # print('grasped object is cone')
                grasp_reward_temporary_list=[]
                force_convex_hull_distance_reward_temporary_list = []
                energy_reward_temporary_list = []
                try:
                    p.removeBody(self.object_Uid)
                except:
                    # print ('No self.object_Uid')
                    None
                self.object_index = i
                self.object_Uid, central_width, central_height = self.choose_object(self.object_index)
                theta = 0
                for theta in [0.0, -math.pi / 4, -math.pi / 2]:
                    for offset in [0.005, 0.01, 0.02]:
                        # print ('offset is {0}'.format(offset))
                        # random_sample_number = 1 + len(self.finger_abduction_adduction_index) * 3
                        for q in range(1):
                            p.resetBasePositionAndOrientation(self.object_Uid,
                                                              [0, 0, 2.0 / 3 * 0.06 * math.cos(math.pi / 12)],
                                                              [0, 0.7930703, 0, 0.6091302])
                            for j in range(self.numJoints):
                                p.resetJointState(self.self_reconstructed_hand_Uid, j, 0)

                            self.reset_hand_position_and_orientation(self.object_index, central_width, central_height,
                                                                     theta,
                                                                     offset)
                            self.finger_abduction_adduction_initial_degree = \
                                self.choose_inital_hand_abduction_adduction_joint_degree(self.object_index,
                                                                                         self.finger_abduction_adduction_index,
                                                                                         self.finger_abduction_adduction_in_which_side)
                            # print ('finger_abduction_adduction_initial_degree is {0}'.format(self.finger_abduction_adduction_initial_degree))
                            grasp_reward,force_convex_hull_distance_reward, energy_reward = self.power_grasp_planner(
                                friction_coefficient, object_gravity, limit_torque_limit, central_width,self.object_index)
                            grasp_reward_temporary_list.append(grasp_reward)
                            force_convex_hull_distance_reward_temporary_list.append(force_convex_hull_distance_reward)
                            energy_reward_temporary_list.append(energy_reward)
                    #         if force_convex_hull_distance_reward == 1000:
                    #             break
                    #     if force_convex_hull_distance_reward == 1000:
                    #         break
                    # if force_convex_hull_distance_reward == 1000:
                    #     break
                grasp_reward_list.append(sorted(grasp_reward_temporary_list,reverse=True)[0])
                force_convex_hull_distance_reward_list.append(
                    sorted(force_convex_hull_distance_reward_temporary_list, reverse=True)[0])
                energy_reward_list.append(sorted(energy_reward_temporary_list, reverse=True)[0])
                if force_convex_hull_distance_reward_list[-1] == self.negative_reward:
                    for k in object_index_number_list[object_index_number_list.index(i) + 1:]:
                        grasp_reward_list.append(self.negative_reward)
                        force_convex_hull_distance_reward_list.append(self.negative_reward)
                        energy_reward_list.append(self.negative_reward)
                    break

        # print ('force_convex_hull_distance_reward_list is {0}'.format(force_convex_hull_distance_reward_list))
        # print ('energy_reward_list is {0}'.format(energy_reward_list))

        grasp_reward_sum = sum(grasp_reward_list)
        force_convex_hull_distance_reward_sum = sum(force_convex_hull_distance_reward_list)
        energy_reward_sum = sum(energy_reward_list)

        # a = 1
        # b = 0.1
        # reward = a * force_convex_hull_distance_reward_sum + b * energy_reward_sum
        # reward = grasp_reward_sum+force_convex_hull_distance_reward_sum+energy_reward_sum
        reward = grasp_reward_sum
        # if reward == 3300:

        if grasp_reward_sum == 4000*len(object_index_number_list):
            self.grasp_flag = 1
        # print ('reward is {0}'.format(reward))
        return reward

    def getExtendedObservation(self):
        self._observation = flatten(self.hand_state)
        return self._observation

    def apply_action_to_configuration(self, action):
        # todo: position is 1-10, length is 1-10, axis is 1-2

        position = int(action[0] * 10 + 1)
        length = int(action[1] * 10 + 1)
        axis = int(action[2] * 2 + 1)

        if position < 1:
            position = 1
        elif position > 10:
            position = 10
        if length < 1:
            length = 1
        elif length > 10:
            length = 10
        if axis < 1:
            axis = 1
        elif axis > 2:
            axis = 2

        # print ('position is {0}'.format(position))
        if position > 0:
            if self.hand_state[position - 1][-1] == 0:
                # todo: the abduction/adduction degree can only be on the finger fisrt joint
                if self.hand_state[position - 1][0] != 0:
                    axis = 1
                # todo: the abduction/adduction length can only be shortest
                # if self.hand_state[position - 1][0] == 0 and axis == 2:
                #     length = 1
                    # #todo:before grasp, encourage grow finger
                    # if self.grasp_flag==0:
                    #     self.reward=self.reward+50
                self.hand_state[position - 1][self.hand_state[position - 1].index(0)] = length
                self.hand_state[position - 1][self.hand_state[position - 1].index(0)] = axis
                self.reward = self.reward - 50
                # if self.grasp_flag==1:
                #     self.reward=self.reward-50
                # elif self.grasp_flag==0:
                #     self.reward=self.reward+50
        elif position < 0:
            if self.hand_state[-position - 1][0] != 0:
                if self.hand_state[-position - 1][-1] == 0:
                    self.hand_state[-position - 1][self.hand_state[-position - 1].index(0) - 1] = 0
                    self.hand_state[-position - 1][self.hand_state[-position - 1].index(0) - 1] = 0
                else:
                    self.hand_state[-position - 1][-1] = 0
                    self.hand_state[-position - 1][-2] = 0
                # self.reward=self.reward+50
                if self.grasp_flag == 1:
                    self.reward = self.reward + 50
                elif self.grasp_flag == 0:
                    self.reward = self.reward - 50

    def get_current_configuration_reward(self, hand_state):
        # todo: reload new hand configuration
        try:
            p.removeBody(self.self_reconstructed_hand_Uid)
        except:
            None
        # todo:because loadurdf has a bug, it cannot load the urdf with the same name, even if the urdf has changed
        # todo:so everytime we add a random float after the urdf name
        if os.path.exists(os.path.join(self.urdfRootPath + '/hand_configuration', self.urdf_file_name)):
            os.remove(os.path.join(self.urdfRootPath + '/hand_configuration', self.urdf_file_name))

        self.urdf_file_name, self.finger_abduction_adduction_index, self.finger_abduction_adduction_in_which_side, self.finger_flex_index \
            = create_hand(self.urdfRootPath + '/hand_configuration', hand_state, self.base_xyz, self.link_length_list,
                          self.link_width)

        self.self_reconstructed_hand_Uid = p.loadURDF(
            os.path.join(self.urdfRootPath + '/hand_configuration', self.urdf_file_name),
            [1, 0, 0.5], [0, 0, 0, 1], useFixedBase=1,
            flags=p.URDF_USE_SELF_COLLISION | p.URDF_USE_SELF_COLLISION_EXCLUDE_PARENT)

        self.numJoints = p.getNumJoints(self.self_reconstructed_hand_Uid)
        self.jointPositions = [0] * self.numJoints
        # print ('current hand numJoints are {0}'.format(self.numJoints))



        # todo: set hand friction
        for i in range(self.numJoints):
            p.changeDynamics(self.self_reconstructed_hand_Uid, i, lateralFriction=0.2, spinningFriction=0.001)
        p.changeDynamics(self.self_reconstructed_hand_Uid, -1, lateralFriction=0.2, spinningFriction=0.001)

        # p.stepSimulation()
        self.render()

        current_reward = self.get_all_reward_for_one_hand_configuration([2,0,1 ], friction_coefficient=0.2,
                                                                        object_gravity=0.01,
                                                                        limit_torque_limit=self.maxForceTorque)

        return current_reward

    def judge_finger_length(self, hand_state, length_limit):
        finger_length_list = []
        for i in range(self.finger_number):
            length = 0
            for j in range(self.single_finger_joint_number):
                length = length + hand_state[i][j * 2]
            finger_length_list.append(length)
        if max(finger_length_list) > length_limit:
            return True
        else:
            return False

    def _termination(self, action):
        if self._envStepCounter >= self._maxSteps:
            return True
        elif self.grasp_flag == 1:
            # print (self.hand_state)
            return True
        elif self.judge_finger_length(self.hand_state, 22) == True:
            self.reward = self.reward - 200
            return True
        # elif int(action[0])==0:
        #     return True
        # elif self.contact_flag_bewteen_hand_and_plane==1:
        #     self.reward=self.reward-5000
        #     return True
        else:
            return False

    def step(self, action):
        self.reward = 0
        for i in range(self._actionRepeat):
            self._envStepCounter += 1
            # print ('begin construct')
            self.apply_action_to_configuration(action)
            # print('end construct')
        # print ('step is {0}'.format(self._envStepCounter))
        # if self._renders:
        #   time.sleep(self._timeStep)
        # print ('hand_state is {0}'.format(self.hand_state))
        # print ('old_hand_state is {0}'.format(self.old_hand_state))
        # todo: if the growth limit is reached, give the negative reward
        if self.hand_state == self.old_hand_state:
            # print ('the same')
            self._observation = self.getExtendedObservation()
            # if int(action[0] * 10 + 1) != 0:
            #     self.reward = self.reward - 100
            # else:
            #     self.reward = self.reward
            self.reward=self.reward-100
            done = self._termination(action)
        # todo: if the hand truely grows, compute the reward
        else:
            # print ('different update')
            self._observation = self.getExtendedObservation()
            self.current_configuration_reward = self.get_current_configuration_reward(self.hand_state)
            self.reward = self.reward + self.current_configuration_reward - self.last_configuration_reward
            self.last_configuration_reward = self.current_configuration_reward
            done = self._termination(action)

        self.old_hand_state = copy.deepcopy(self.hand_state)
        # print ('reward is {0}'.format(self.reward))
        return np.array(self._observation), self.reward, done, {}

    def render(self, mode="rgb_array", close=False):
        if mode != "rgb_array":
            return np.array([])

        base_pos, orn = self._p.getBasePositionAndOrientation(self.self_reconstructed_hand_Uid)
        view_matrix = self._p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=base_pos,
                                                                distance=self._cam_dist,
                                                                yaw=self._cam_yaw,
                                                                pitch=self._cam_pitch,
                                                                roll=0,
                                                                upAxisIndex=2)
        proj_matrix = self._p.computeProjectionMatrixFOV(fov=60,
                                                         aspect=float(RENDER_WIDTH) / RENDER_HEIGHT,
                                                         nearVal=0.1,
                                                         farVal=100.0)
        (_, _, px, _, _) = self._p.getCameraImage(width=RENDER_WIDTH,
                                                  height=RENDER_HEIGHT,
                                                  viewMatrix=view_matrix,
                                                  projectionMatrix=proj_matrix,
                                                  renderer=self._p.ER_BULLET_HARDWARE_OPENGL)
        # renderer=self._p.ER_TINY_RENDERER)

        rgb_array = np.array(px, dtype=np.uint8)
        rgb_array = np.reshape(rgb_array, (RENDER_HEIGHT, RENDER_WIDTH, 4))

        rgb_array = rgb_array[:, :, :3]
        return rgb_array