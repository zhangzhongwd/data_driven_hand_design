from setuptools import setup

setup(name='pybullet_envs_zhong',
      version='0.0.1',
      install_requires=['gym','pybullet']  # And any other dependencies foo needs
)